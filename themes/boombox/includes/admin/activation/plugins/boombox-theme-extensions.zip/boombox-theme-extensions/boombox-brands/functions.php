<?php

/**
 * Brands
 *
 * @package BoomBox_Theme_Extensions
 */

/**
 * Register Brands
 */
include_once( 'register-brands.php' );

/**
 * Add metabox to Brands
 */
include_once( 'lib/class-boombox-brands-metabox.php' );