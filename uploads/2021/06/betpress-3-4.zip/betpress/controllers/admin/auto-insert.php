<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_auto_insert_controller() {
    wp_enqueue_script('js_admin', plugins_url('/includes/js/admin.js', __FILE__), array('jquery', 'js_timepicker', 'wp-color-picker'), true, true);
    if (isset($_POST['sport_id'])) {
        	
        $sport_id = (int) betpress_sanitize($_POST['sport_id']);
        
        $events = isset($_POST['events']) ? $_POST['events'] : null;
		
		
		
			
        
        $bet_events = isset($_POST['bet_events']) ? $_POST['bet_events'] : null;
        
        $cats = isset($_POST['categories']) ? $_POST['categories'] : null;
        
        $errors = array();
        
        if (0 === $sport_id) {
            
            $errors [] = __('Nenhum esporte selecionado.', 'betpress');
        }
        
        if ( ! is_array($events) ) {
            
            $errors [] = __('Nenhum evento selecionado.', 'betpress');
            
        } else {
            
            $events_filtered = array();
            
            foreach ($events as $key => $event) {
                
                $events_filtered [$key] = explode('/', betpress_sanitize($event));
                
                if (count($events_filtered[$key]) != 2) {
                    
                    $errors [] = __('Dados inválidos passados.', 'betpress');
                    
                }
            }
        }
        
        if ( ! is_array($bet_events) ) {
            
            $errors [] = __('Nenhum evento de aposta selecionado.', 'betpress');
            
        } else {
            
            $bet_events_filtered = array();
            
            foreach ($bet_events as $key => $bet_event) {
                
                $bet_events_filtered [$key] = explode('/', betpress_sanitize($bet_event));
                
                if (count($bet_events_filtered[$key]) != 2) {
                    
                    $errors [] = __('Dados inválidos passados.', 'betpress');
                    
                }
            }
        }
        
        if ( ! is_array($cats) ) {
            
            $errors [] = __('Nenhuma categoria selecionada.', 'betpress');
            
        } else {
            
            $cats_filtered = array();
            
            foreach ($cats as $key => $cat) {
                
                $cats_filtered [$key] = explode('/', betpress_sanitize($cat));
                
                if (count($cats_filtered[$key]) != 2) {
                    
                    $errors [] = __('Dados inválidos passados.', 'betpress');
                    
                }
            }
        }
        
        if ( ! empty($errors) ) {
            
            foreach ($errors as $err) {
                
                $pass['error_message'] = $err;
                betpress_get_view('error-message', 'admin', $pass);
                
            }
            
        } else {
        
            $data = array();
		
            foreach ($events_filtered as $event) {

                if ($event[1] == $sport_id) {

                    $data [$event[1]] [$event[0]] = array();

                    foreach ($bet_events_filtered as $bet_event) {

                        if ($bet_event[1] == $event[0]) {

                            $data [$event[1]] [$bet_event[1]] [$bet_event[0]] = array();

                            foreach ($cats_filtered as $cat) {
                                
                                if ($cat[1] == $bet_event[0]) {

                                    $data [$event[1]] [$bet_event[1]] [$cat[1]] [$cat[0]] = array();
                                    
                                }
                            }
                        }
                    }
                }
            }
            
            $is_active = isset($_POST['auto_activate']) ? 1 : 0;

            if (betpress_insert_specific_xml_data($data, $is_active) === true) {
                
                $pass['update_message'] = __('Dados selecionados foram inseridos.', 'betpress');
                betpress_get_view('updated-message', 'admin', $pass);
					global $wpdb;
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_events_cats WHERE bet_event_cat_name ="Bloqueado"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Outro Resultado"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +0"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +1"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +2"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +3"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +4"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -0"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -1"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -2"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -3"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -4"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +0"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +1"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +2"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +3"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +4"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -0"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -1"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -2"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -3"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -4"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -5"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa +1)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa +2)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa +3)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa +4)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa +5)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa -1)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa -2)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa -3)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa -4)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Casa -5)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora +1)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora +2)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora +3)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora +4)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora +5)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora -1)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora -2)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora -3)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora -4)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Empate (Fora -5)"');				
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +0.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +1.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +2.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +3.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +4.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +5.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +6.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +7.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +8.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +9.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +10.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +11.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +12.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +13.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +14.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +15.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +16.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +17.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +18.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +19.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +20.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +21.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +22.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +23.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +24.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +25.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +26.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +27.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +28.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +29.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +30.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +31.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +32.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +33.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +34.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +35.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +36.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +37.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +38.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +39.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa +40.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +0.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +1.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +2.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +3.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +4.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +5.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +6.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +7.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +8.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +9.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +10.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +11.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +12.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +13.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +14.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +15.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +16.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +17.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +18.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +19.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +20.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +21.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +22.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +23.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +24.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +25.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +26.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +27.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +28.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +29.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +30.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +31.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +32.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +33.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +34.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +35.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +36.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +37.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +38.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +39.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora +40.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -0.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -1.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -2.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -3.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -4.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -5.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -6.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -7.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -8.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -9.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -10.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -11.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -12.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -13.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -14.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -15.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -16.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -17.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -18.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -19.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -20.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -21.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -22.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -23.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -24.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -25.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -26.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -27.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -28.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -29.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -30.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -31.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -32.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -33.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -34.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -35.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -36.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -37.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -38.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -39.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Fora -40.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -0.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -1.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -2.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -3.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -4.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -5.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -6.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -7.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -8.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -9.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -10.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -11.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -12.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -13.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -14.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -15.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -16.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -17.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -18.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -19.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -20.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -21.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -22.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -23.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -24.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -25.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -26.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -27.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -28.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -29.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -30.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -31.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -32.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -33.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -34.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -35.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -36.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -37.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -38.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -39.5"');
	$wpdb->query('DELETE FROM '.$wpdb->prefix.'bp_bet_options WHERE bet_option_name ="Casa -40.5"');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.44; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.88; ');				
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.51; ');				
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.24; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.51; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.65; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.46; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.24; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.33; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.18; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.47; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.61; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.72; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.12; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.32; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.01; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.79; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.27; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.82; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.48; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.93; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.07; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.49; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.70; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.53; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.62; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.90" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.91; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.90" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.92; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.94; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.58; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.17; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.79; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.13; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.58; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.23; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.62" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.71; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.87; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.11; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.22; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="29.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 29.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.74; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.40; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.62" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.67; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.98; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.90" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.93; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.20; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.57; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.37; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.31; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.27; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.15; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.62; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.23; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.78; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.86; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.29; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.08; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.87; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.80; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.97; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.63; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.95" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.96; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.85" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.84; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.99; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.93; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.22; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.28" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.27; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.15; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.10; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.26; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.10; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="19.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 19.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.35; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.31; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.79; ');				
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.83; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.20; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.22; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="10.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.10; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.42; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.14; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.38; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.37" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.38; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.42; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.97; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.96; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.59; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.02; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.15" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.21; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.40; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.05" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.09; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.05; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.62" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.64; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.23; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.86; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.57; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.83; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.12; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.57; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.22" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.23; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.61" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.64; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="15.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 14.33; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.47; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.37" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.41; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.70; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.73; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.38; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.34; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.13; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.11; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="29.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 30.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.83; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.46; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.35; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.68; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.56; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="29.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 27.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.53" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.54; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.33; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.07; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="34.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 31.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.93; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.90" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.91; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.88; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.98; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.65; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.05; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.84; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.70; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.97; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.70" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.69; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.04; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.43; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.02; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.31; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="16.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 15.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.60; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.05; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.73; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.66" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.68; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.57" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.62; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.68; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.67; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.03; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.90; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.53; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.54; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.63; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.78; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.68; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.80; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.80; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.18; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.99; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.81; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="17.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 16.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.57" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.58; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="13.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 13.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.55; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.51; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.73; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.76; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.15; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.07" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.08; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.05" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.06; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.37" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.39; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="11.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 10.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.80; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="10.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.35; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.43; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.66; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.32; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.40; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.47" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.48; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.60; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.62; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.92; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.49; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="19.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 18.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.18; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="17.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 16.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.72; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.67; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="151.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 110.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.57" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.56; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.27; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.52; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.55; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="12.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 12.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.72" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.71; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.58; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.60; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="13.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 13.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="13.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 13.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.88; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.48; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.15; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.30; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.55; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="34.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 31.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.19; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.39; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.77; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="51.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 50.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="41.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 40.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.15" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.16; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.98; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.48; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.08; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="10.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 10.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.30; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="34.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 35.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="15.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 14.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.98; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.95; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="21.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 21.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.82; ');		
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.28; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.29; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.12; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.32; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.17; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.45; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.44; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.37" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.36; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.53; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.30; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="15.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 15.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.99; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.82; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.55; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="41.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 38.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="12.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 11.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.36" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.35; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.52; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.52; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.32; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.70; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.03; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.89; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.40; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.78; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.45" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.47; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.10; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.30" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.28; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="12.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 11.25; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.42; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.77; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.90" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.89; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.85; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.35; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.17; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="13.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 12.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.55; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="101.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 100.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.74; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="201.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 101.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="101.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 90.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="81.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 80.00; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="13.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 12.50; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.75; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.30; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.15; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.15; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.23; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.33" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.28; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.25" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 5.20; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.70" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.69; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.97; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="10.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.80; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.62" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.63; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.80" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.81; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.15; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="21.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 20.50; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.57" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.59; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.40; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.10; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.35; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.03; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.05; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.43; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.30; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.60; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="8.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.30; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.77; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.20; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.05; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.88; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.70; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.75" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.55; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.02; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.10" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.13; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="15.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 14.25; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="12.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 11.50; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 8.95; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.10; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.47" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.46; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.53" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.52; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="51.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 45.50; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="51.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 53.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="29.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 27.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="67.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 60.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="67.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 70.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="51.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 55.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="126.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 125.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="81.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 85.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="201.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 200.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="126.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 125.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.60" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.54; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.36; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="2.87" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 2.89; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="5.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 4.99; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.41; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.40" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.34; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="6.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 6.60; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="7.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 7.55; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="1.14" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 1.13; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="81.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 75.00; ');
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="3.20" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.19; ');	
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="4.00" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 3.92; '); 
$wpdb->query('UPDATE '.$wpdb->prefix.'bp_bet_options SET bet_option_odd ="9.50" WHERE `jmtpc_bp_bet_options`.`bet_option_odd` = 9.90; ');				
            } else {
                
                $pass['error_message'] = __('Erro de banco de dados.', 'betpress');
                betpress_get_view('error-message', 'admin', $pass);
                
            }
        }
    }
    
    $pass['xml_data'] = betpress_get_xml_data();
    betpress_get_view('auto-insert', 'admin', $pass);
    
}