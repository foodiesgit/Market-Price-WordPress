<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

	global $wpdb;
	$check = $wpdb->get_results('SELECT * from '.$wpdb->prefix . 'bp_slips');
//print_r($check);
	//$str_val = $check[0]->bet_options_ids;

function betpress_add_bet_option() {

    //codex says i MUST do this if
    if (is_admin() === true) {

        $db_errors = false;

        $bet_option_ID = (int) betpress_sanitize($_POST['bet_option_id']);
        $bet_option_errors = array();

        $user_ID = get_current_user_id();
        $wl = get_user_meta($user_ID, 'betpress_lang', true);
        $wl0 = isset($_COOKIE['betpress_lang_type']) ? betpress_sanitize($_COOKIE['betpress_lang_type']) : get_option('bp_default_lang_type');
		$balance = get_user_meta($user_ID, 'balance', true);
		
        if (0 === $user_ID) {

            $bet_option_errors [] = __('Por favor faça Login para Apostar', 'betpress');

        }
		
       if ( in_array($user_ID, array('2484', '2660', '2470', '3171', '229'))) {		

		   $bet_option_errors [] = __('Sorry! Você já cumpriu o seu rollover, o seu bônus já não pode ser mais utilizado, efetue o Saque dos fundos em questão, para apostar você deve depositar fundos, caso está mensagem seja um erro contate-nos.', 'betpress');

     }
		
       if ($user_ID == "11004") {

            $bet_option_errors [] = __('Clique em um preço para adicionar uma seleção', 'betpress');

        }		

        if ( ! betpress_is_bet_option_exists($bet_option_ID) ) {

            $bet_option_errors [] = __('Impossível adicionar esta aposta!', 'betpress');
        }

        $bet_option_details = betpress_get_bet_option($bet_option_ID);

        $seconds_to_close_bets_earlier = (int) get_option('bp_close_bets');

        $bet_event_close_time = $bet_option_details['deadline'] - $seconds_to_close_bets_earlier;

        if ($bet_event_close_time <= time()) {
        $bet_option_errors [] = __('Lamentamos, mas esta página já não está disponivel. As Apostas fecharam ou foram suspensas.', 'betpress');
		}
		
        $bet_option_details = betpress_get_bet_option($bet_option_ID);

        $bet_option_name = $bet_option_details['bet_option_name'];
        
		$evii = $bet_option_details['bet_event_cat_name'];
		
		$bop = $bet_option_details['bet_option_name'];

if (( in_array($balance, array('bonus'))) && ($evii != "Resultado Final") && ($evii != "Para Vencer a Partida") && ($user_ID != "3697")) {
         $bet_option_errors [] = __('Seu bônus lhe permite apostar apenas nos mercados Resultado Final de Futebol.', 'betpress');
}
		
if (( in_array($balance, array('bonus'))) && ($bop == "Empate")) {
         $bet_option_errors [] = __('Nosso setor antifraude está investigando tentativas de burlar o sistema, onde o utilizador mal-intencionado abre várias contas e cercas os resultados o que é proíbido, todas estas contas estão sendo investigadas, quando recebermos o laudo dos analistas comprovando iremos encerrar todas estas contas, por tanto está opção de aposta está desabilitada no momento até o fim da análise, caro utilizador bem intencionado não iremos lhe prejudicar, para saber mais entre em contato conosco.', 'betpress');
}		
		
        if ( ! empty($bet_option_errors) ) {

            foreach ($bet_option_errors as $err) {
if ((0 === $user_ID) && ( in_array($wl0, array('en'))) OR ( in_array($wl, array('en')))) {
$err = str_replace( 'Lamentamos, mas esta página já não está disponivel. As Apostas fecharam ou foram suspensas.', 'Sorry, this page is no longer available. Bets have closed or been suspended.', $err );	
$err = str_replace( 'Por favor faça Login para Apostar', 'Please Login to Bet', $err );		 
$err = str_replace( 'Clique num preço para adicionar uma seleção.', 'Click on a price to add a selection.', $err );
}
                $pass['error_message'] = $err;
                betpress_get_view('error-message', '', $pass);
            }

        } else {

            $unsubmitted_slip = betpress_get_user_unsubmitted_slip($user_ID);

            //if there is no unsubmitted slip for this user, we have to create one for him
            if ( ! $unsubmitted_slip ) {

                //save his first betting option in array
                $bet_option_ids = array($bet_option_ID => $bet_option_details['bet_option_odd']);

                //package it for db
                $serialized_bet_options = serialize($bet_option_ids);

                //send it to db
               // echo $user_ID.'-'.$serialized_bet_options;exit;
                $insert = betpress_insert(
                        'slips',
                        array(
                            'user_id' => $user_ID,
                            'bet_options_ids' => $serialized_bet_options,
                            'status' => betpress_STATUS_UNSUBMITTED,
                            'date' => time(),
                        )
                );
                if (false === $insert) {
                    $db_errors = true;
                }

            } else {

                //get current slip id
                $slip_ID = $unsubmitted_slip['slip_id'];

                //get current bet options from db
                $serialized_bet_options = $unsubmitted_slip['bet_options_ids'];

                //make them an array
                $bet_option_ids = unserialize($serialized_bet_options);

                $errors = array();
				$will_be_deleted = false;
                if (array_key_exists($bet_option_ID, $bet_option_ids)) {

                    $errors [] = __('Você não pode adicionar duas opções da mesma categoria.', 'betpress');
                    global $wpdb;
					//$_POST['bet_option_id'] = $bet_option_ID;
					$will_be_deleted = true;
					echo "<script>
					jQuery('#bet-option-btn-'+$bet_option_ID).removeClass('active');
					var del_id = jQuery('#delete-".$bet_option_ID."').attr('data');
					var del_index = odds.indexOf(del_id);
					if( del_index > -1 ){
					   odds.splice(del_index,1);
					   if(odds.length == 0){
                          jQuery('#pw').html('0.00');
                       }

                       do_calculation();
					}
					jQuery('#delete-".$bet_option_ID."').trigger('click');
					</script>";
                  	//betpress_delete_bet_option();
					//$errors [] = '';

                } else if (get_option('bp_one_win_per_cat') === betpress_VALUE_YES) {
                    //check for bet option of the same category

                    $used_categories = array();

                    foreach ($bet_option_ids as $bet_option_id => $bet_option_odd) {
                        $used_categories [] = betpress_get_bet_option_cat($bet_option_id);
						//$_POST['bet_option_id'] = $bet_option_id;
                  	    //betpress_delete_bet_option();
                  	    if(betpress_get_bet_option_cat($bet_option_id) == $bet_option_details['bet_event_cat_id']){
							$will_be_deleted = true;
							echo "<script>
							jQuery('#bet-option-btn-'+$bet_option_id).removeClass('active');
 							var del_id = jQuery('#delete-".$bet_option_id."').attr('data');
 							var del_index = odds.indexOf(del_id);
 							if( del_index > -1 ){
 							   odds.splice(del_index,1);
 							   if(odds.length == 0){
 								  jQuery('#pw').html('0.00');
 							   }

 							   do_calculation();
 							}
 							jQuery('#delete-".$bet_option_id."').trigger('click');

							</script>";
						}
                    }

                    if (in_array($bet_option_details['bet_event_cat_id'], $used_categories)) {
                        //print_r($used_categories);
                        //$errors [] = __('Você não pode adicionar duas opções da mesma categoria.', 'betpress');
                    }
                }
				
				if(!$will_be_deleted) {
					//add to them the current bet option
                    $bet_option_ids [$bet_option_ID] = $bet_option_details['bet_option_odd'];
					$event_bet_counts = array();
					foreach($bet_option_ids as $bet_option_id => $odd) {
						$bet_option = betpress_get_bet_option($bet_option_id);
						$bet_event_id = $bet_option['bet_event_id'];
						$t_home = $bet_option['team_home'];
						$nopsevent = $bet_option_details['event_name'];
						if(!isset($event_bet_counts[$bet_event_id]))
							$event_bet_counts[$bet_event_id] = 0;
						if ($nopsevent == "NBA 2K21 - Liga de Elite - 4x5min") {
						if(++$event_bet_counts[$bet_event_id] == 4) {
							$errors [] = __('Criar Aposta lhe permite selecionar apenas 3 opções em cada partida.', 'betpress');
							break;
						}
					 } else if ($t_home == "Concurso") {
						if(++$event_bet_counts[$bet_event_id] == 6) {
							$errors [] = __('Selecione no mínimo 5 bolas', 'betpress');
							break;
						}
					} else if (++$event_bet_counts[$bet_event_id] == 2) {
							$errors [] = __('Você não poderá selecionar mais de 1 opções na mesma partida', 'betpress');
							break;							
				   }
				}		
					unset($bet_option_ids [$bet_option_ID]);
		        }	
				
                if (empty($errors)) {

                    //add to them the current bet option
                    $bet_option_ids [$bet_option_ID] = $bet_option_details['bet_option_odd'];

                    //package to send to db
                    $serialized_bet_options_updated = serialize($bet_option_ids);

                    //send to db
                    $update = betpress_update(
                            'slips',
                            array(
                                'bet_options_ids' => $serialized_bet_options_updated,
                            ),
                            array(
                                'slip_id' => $slip_ID,
                            )
                    );

                    if (false === $update) {
                        $db_errors = true;
                    }
                } else {

                    foreach ($errors as $error) {
if ((0 === $user_ID) && ( in_array($wl0, array('en'))) OR ( in_array($wl, array('en')))) {
$error = str_replace( 'Você não pode adicionar duas opções da mesma categoria.', 'You cannot add two options from the same category.', $error );		 
$error = str_replace( 'Você não poderá selecionar mais de 1 opções na mesma partida', 'You cannot select more than 1 options in the same match', $error );		 
$error = str_replace( 'Selecione no mínimo 5 bolas', 'Select at least 5 balls', $error );
}
                        $pass['error_message'] = $error;
                        betpress_get_view('error-message', '', $pass);
                    }
                }
            }
        }

        if (false === $db_errors) {

            if ( ! isset($bet_option_ids) ) {

                $user_ID = get_current_user_id();

                $unsubmitted_slip = betpress_get_user_unsubmitted_slip($user_ID);

                if (empty($unsubmitted_slip)) {

                    $bet_option_ids = array();

                } else {

                    $bet_option_ids = unserialize($unsubmitted_slip['bet_options_ids']);

                }

            }

            //show current bet options
            betpress_render_bet_options($bet_option_ids);

        } else {

            _e('DB error.', 'betpress');
            wp_die();
        }
    }

    //codex says i MUST use wp_die
    wp_die();
}

add_action('wp_ajax_add_bet_option', 'betpress_add_bet_option');
add_action('wp_ajax_nopriv_add_bet_option', 'betpress_add_bet_option');