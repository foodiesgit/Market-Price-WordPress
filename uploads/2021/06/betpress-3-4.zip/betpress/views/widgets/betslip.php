<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<script>var odds = []; var pw_ids = [];</script>
<div id="betslip-wrapper">

<?php if ($show_points): ?>

    <?php if (get_current_user_id()): ?>

<?php
global $wpdb;
$user_ID = get_current_user_id();
$currency = get_user_meta($user_ID, 'currency', true);	
$eur = get_user_meta($user_ID, 'mycred_eur', true);
$brl = get_user_meta($user_ID, 'mycred_default', true);
$wl = get_user_meta($user_ID, 'betpress_lang', true);
$wl0 = isset($_COOKIE['betpress_lang_type']) ? betpress_sanitize($_COOKIE['betpress_lang_type']) : get_option('bp_default_lang_type');	
?>
        <div class="points-holder">
 			
<?php if ( in_array($currency, array('BRL'))): ?>
<div style="width=100%!important"><?php printf(__('Disponível: R$ %s', 'betpress'), number_format($brl,2,',','')); ?> </div>
<div style="width=100%!important"><?php printf(__('Bônus: R$ %s', 'betpress'), number_format($eur,2,',','')); ?> </div>
<?php endif; ?>
			
<?php if ( in_array($currency, array('EUR'))): ?>
<div style="width=100%!important"><?php printf(__('Disponível: %s EUR', 'betpress'), number_format($brl,2,',','')); ?> </div>
<div style="width=100%!important"><?php printf(__('Bonus: %s EUR', 'betpress'), number_format($eur,2,',','')); ?> </div>
<?php endif; ?>	
			
<?php if ( in_array($currency, array('USD'))): ?>
<div style="width=100%!important"><?php printf(__('Disponível: %s USD', 'betpress'), number_format($brl,2,',','')); ?> </div>
<div style="width=100%!important"><?php printf(__('Bonus: %s USD', 'betpress'), number_format($eur,2,',','')); ?> </div>
<?php endif; ?>	
			
<?php if ( in_array($currency, array('RUB'))): ?>
<div style="width=100%!important"><?php printf(__('Disponível: %s RUB', 'betpress'), number_format($brl,2,',','')); ?> </div>
<div style="width=100%!important"><?php printf(__('Bonus: %s RUB', 'betpress'), number_format($eur,2,',','')); ?> </div>
<?php endif; ?>	
			
<?php if ( in_array($currency, array('GBP'))): ?>
<div style="width=100%!important"><?php printf(__('Disponível: %s GBP', 'betpress'), number_format($brl,2,',','')); ?> </div>
<div style="width=100%!important"><?php printf(__('Bonus: %s GBP', 'betpress'), number_format($eur,2,',','')); ?> </div>
<?php endif; ?>				

        </div>

    <?php endif; ?>

<?php endif; ?>

    <div class="bets-holder">

<?php if ($bet_options): ?>

    <?php foreach ($bet_options as $bet_option_info): ?>

        <?php betpress_get_view('widget-bet-options', '', array('bet_option_info' => $bet_option_info)); ?>

    <?php endforeach; ?>

<?php else: ?>

<?php betpress_get_view('info-message', '', array('info_message' => esc_attr__('Clique em um preço para adicionar uma seleção', 'betpress'))); ?>		
		
<?php endif; ?>

    </div>
	<?php if (($currency == 'EUR') && ((0 === $user_ID) && ( in_array($wl0, array('br'))) OR ( in_array($wl, array('br'))))) : ?>
    <div class="pw"><?php esc_attr_e('Para Retornar €', 'betpress'); ?><span id="pw">0.00</span></div>
	<?php endif; ?>
	
	<?php if (($currency == 'EUR') && ((0 === $user_ID) && ( in_array($wl0, array('en'))) OR ( in_array($wl, array('en'))))) : ?>
    <div class="pw"><?php esc_attr_e('To Return €', 'betpress'); ?><span id="pw">0.00</span></div>
	<?php endif; ?>	
	
	<?php if (($currency == 'EUR') && ((0 === $user_ID) && ( in_array($wl0, array('es'))) OR ( in_array($wl, array('es'))))) : ?>
    <div class="pw"><?php esc_attr_e('Ganancias €', 'betpress'); ?><span id="pw">0.00</span></div>
	<?php endif; ?>	
	
	<?php if ($currency != 'EUR'): ?>
	<div class="pw"><?php esc_attr_e('Para Retornar R$', 'betpress'); ?><span id="pw">0.00</span></div>
    <?php endif; ?>

    <button type="button" class="clear_all_bet_option"><?php esc_attr_e('Limpar Tudo', 'betpress'); ?></button>

	 <div class="actions-holder">

        <div id="input-stake-holder">

            <input
                type="number"
                placeholder="<?php esc_attr_e('Valor', 'betpress'); ?>"
                min="1"
                step="<?php echo get_option('bp_only_int_stakes') ? 1 : 0.01 ?>"
                id="stake-input"
                name="stake"
                />

        </div>

        <div class="submit-slip">
			 <?php if ((0 === $user_ID) && ($wl0 == 'en') OR ($wl == 'en')): ?>
             <button id="submit-slip-button"><?php esc_attr_e('Place Bet', 'betpress'); ?></button>
			 <?php endif; ?>
			
			 <?php if ((0 === $user_ID) && ($wl0 != 'en') OR ($wl != 'en')): ?>
             <button id="submit-slip-button"><?php esc_attr_e('Apostar', 'betpress'); ?></button>
			 <?php endif; ?>			
        </div>

        <div class="clear"></div>
    </div>

</div>