<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<div class="paypal-success-message">
    
    <?php echo $paypal_success_message; ?>
    
</div>