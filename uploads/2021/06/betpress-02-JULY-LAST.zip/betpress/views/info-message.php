<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<div class="info-holder">
        
    <?php echo $info_message; ?>
    
</div>