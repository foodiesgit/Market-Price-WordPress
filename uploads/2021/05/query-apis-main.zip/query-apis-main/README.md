# Query APIs
Simple plugin with a Menu Page to see the results of an API Query in WordPress.

## Installation

1. Download the Zip from the repository
1. Install and activate the plugin through the 'Plugins' screen in WordPress
1. View the Admin Menu to see the APIs you are querying in the code.
