<?php
/*
Plugin Name: Display Realtime JSON Data through Ajax
Description: Lets you diplay JSON data from any URL. Helpful for showing any real time activity like Current live Event updating frequently, Current Playing Songs OR Movies from third party URL
Version: 1.0
Author: Mahesh Bisen
Author URI: http://github.com/maheshbisen
Text Domain: drjsondata
License: GPL2
Version: 1.0
*/


// plugin variable: drjsondata


//  plugin functions
register_activation_hook( 	__FILE__, "drjsondata_activate" );
register_deactivation_hook( __FILE__, "drjsondata_deactivate" );
register_uninstall_hook( 	__FILE__, "drjsondata_uninstall" );

function drjsondata_activate() {
	
	// default options
	$drjsondata_options = array(
		'drjsondata-json-url'    		=> 'sample.json',
		'drjsondata-data-format'    	=> '<div>Name: %%name%%</div><div>Age: %%age%%</div><div>City: %%city%%</div>'
	);
	
	add_option("drjsondata_options", $drjsondata_options);
	
}

function drjsondata_deactivate() {	
	delete_option("drjsondata_my_plugin_notice_shown");
}

function drjsondata_uninstall() {
}

// admin includes
if (is_admin()) {
	include_once('admin/drjsondata_settings.php');
	include_once('admin/drjsondata_nav.php');
}


add_action( 'wp_enqueue_scripts', 'drjsondata_submit_scripts' );
add_action( 'wp_ajax_refreshJsonData', 'drjsondata_myajax_refreshJsonData' );
add_action( 'wp_ajax_nopriv_refreshJsonData', 'drjsondata_myajax_refreshJsonData' );
function drjsondata_submit_scripts() {
    wp_enqueue_script( 'drjsondata_submit', plugin_dir_url( __FILE__ ) . 'assets/js/load-json-data.js', array( 'jquery' ) );
    wp_localize_script( 'drjsondata_submit', 'PT_Ajax', array(
            'ajaxurl'   => admin_url( 'admin-ajax.php' ),
            'nextNonce' => wp_create_nonce( 'drjsondata-myajax-next-nonce' )
        )
    );
}


function drjsondata_myajax_refreshJsonData() {
    // check nonce
    $nonce = $_POST['nextNonce'];
    if ( ! wp_verify_nonce( $nonce, 'drjsondata-myajax-next-nonce' ) ) {
        die ( 'Busted!' );
    }


    // get settings
    $options = get_option('drjsondata_options');

    if ( empty( $options['drjsondata-json-url'] ) ) { 
        $options['drjsondata-json-url'] = 'sample.json'; 
    }

    if (empty($options['drjsondata-data-format'])) {
        $options['drjsondata-data-format'] = 'Configuration Error.'; 
    }

    
    // read data from remote JSON using wp http api
    $drjsondata_response    = wp_remote_get( $options['drjsondata-json-url'] );
    $drjsondata_http_code   = wp_remote_retrieve_response_code( $drjsondata_response );

    if( $drjsondata_http_code == 200 ) {
        $drjsondata_json_content = wp_remote_retrieve_body( $drjsondata_response );

        // check if string is surrounded in double or single quotes, if so remove
        if ( preg_match('#^(\'|").+\1$#', $drjsondata_json_content) == 1) {
            $rawData =  substr(stripslashes($drjsondata_json_content), 1, -1);
        } else {
            $rawData =  stripslashes($drjsondata_json_content);
        }

        // convert json content into array/object
        $data_initially_called = json_decode($rawData, false);


        
        if( is_object($data_initially_called) ){
            $data_initially_called = drjsondata_dismount( $data_initially_called );
        }


        $drjsondatdata = drjsondata_array_flatten($data_initially_called);

        $arr1 = array();
        $arr2 = array();

        $usableFormatStrings = "";

        foreach( $drjsondatdata as $key=>$val ) {
            $arr1[] = '%%'.$key.'%%';
            $arr2[] = $val;
            $usableFormatStrings .= $key.","; 
        }


        $prodata = stripcslashes( $options['drjsondata-data-format'] );
        $processData = str_replace( $arr1, $arr2, $prodata );

    } else {
        $processData = '<span class="file_error">file error....</span>';
    }



    $response_build = array( html_entity_decode( $processData ) );
    $response = json_encode( $response_build );
    
    // response output
    header( "Content-Type: application/json" );
    echo $response;

    exit;
}

function drjsondata_show_json_realtime_data() {

    $options = get_option('drjsondata_options');

    if ( empty( $options['drjsondata-json-url'] ) ) { 
        $options['drjsondata-json-url'] = plugin_dir_url( __FILE__ ).'../sample.json'; 
    }

    if ( empty( $options['drjsondata-data-format'] ) ) {
        $options['drjsondata-data-format'] = '<div>Entity 1: %%Entity1%%</div><div>Entity 2: %%Entity2%%</div><div>Entity 3: %%Entity3%%</div>'; 
    }


    // Fire javascript if refresh timer has setup by admin
    if ( !empty( $options['drjsondata-update-in-time'] ) && $options['drjsondata-update-in-time'] > 0 ) {

        echo '<script type="text/javascript">
            jQuery(document).ready(function(){
                console.log('.$options['drjsondata-update-in-time'].');
                drjsondata_fetchdata("'.plugin_dir_url( __FILE__ ).'");
                setInterval(function(){ drjsondata_fetchdata("'.plugin_dir_url( __FILE__ ).'"); }, '.$options['drjsondata-update-in-time'].');
            });
        </script>';
    }

    // read data from remote JSON using wp http api
    $drjsondata_response    = wp_remote_get( $options['drjsondata-json-url'] );
    $drjsondata_http_code   = wp_remote_retrieve_response_code( $drjsondata_response );

    if( $drjsondata_http_code == 200 ) {
        $drjsondata_json_content = wp_remote_retrieve_body( $drjsondata_response );

        // check if string is surrounded in double or single quotes
        if ( preg_match('#^(\'|").+\1$#', $drjsondata_json_content) == 1) {
            $rawData =  substr(stripslashes($drjsondata_json_content), 1, -1);
        } else {
            $rawData =  stripslashes($drjsondata_json_content);
        }

        // convert json content into array/object
        $data_initially_called = json_decode($rawData, false);


        
        if( is_object($data_initially_called) ){
            $data_initially_called = drjsondata_dismount( $data_initially_called );
        }


        $drjsondatdata = drjsondata_array_flatten($data_initially_called);

        $arr1 = array();
        $arr2 = array();

        $usableFormatStrings = "";

        foreach( $drjsondatdata as $key=>$val ) {
            $arr1[] = '%%'.$key.'%%';
            $arr2[] = $val;
            $usableFormatStrings .= $key.","; 
        }


        $prodata = stripcslashes($options['drjsondata-data-format']);
        $processData = str_replace( $arr1, $arr2, $prodata );
    } else { 
        $processData = '<span class="file_error">file error....</span>';
    }

    echo '<div id="drjsondataCont">';
    echo html_entity_decode($processData);
    echo '</div>';

}
add_shortcode( 'show-json-realtime-data' , 'drjsondata_show_json_realtime_data' );


function drjsondata_array_flatten( $array ) { 
    
    if ( !is_array($array) ) { 
        return FALSE; 
    } 

    $result = array();

    foreach ( $array as $key => $value ) { 
        if ( is_array($value) ) { 
          $result = array_merge( $result, drjsondata_array_flatten( $value ) ); 
        } 
        else { 
          $result[$key] = $value; 
        } 
    } 
    return $result; 
}

function drjsondata_dismount( $data ) {

    if ( is_object( $data ) ) {
        $data = get_object_vars($data);
    }

    if ( is_array( $data ) ) {
        return array_map(__FUNCTION__, $data);
    }

    return $data;
}