function drjsondata_fetchSampleDataAdmin( pluginURL ) {

		jQuery('.ddataPreviewCont').show();

		jQuery('.dataPreviewCont').html('<img class="loader" src="'+pluginURL+'../assets/img/drjsondat_loader.gif" alt="loader" title="loader"/>');	

		var data = {
			'action': 'drjsondata_displayJsonDataPreview',
		};

		// Display Preview 
		jQuery.post(drjsondata_object.ajax_url, data, function(response) {
			jQuery('.dataPreviewCont').html(response[0]);
		});

}

function drjsondata_fetchSampleJSONPreivewAdmin( pluginURL ) {

		jQuery('.jsonPreviewCont').show();

		jQuery('.jsonPreviewCont').html('<img class="loader" src="'+pluginURL+'../assets/img/drjsondat_loader.gif" alt="loader" title="loader"/>');	

		var data = {
			'action': 'drjsondata_displayJsonPreview',
		};

		// Display Preview 
		jQuery.post(drjsondata_object.ajax_url, data, function(response) {
			jQuery('.jsonPreviewCont').html(response[0]);
		});

}