function drjsondata_fetchdata( pluginURL ){
		console.log(Date.now());
		jQuery('#drjsondataCont').html('<img class="loader" src="'+pluginURL+'assets/img/drjsondat_loader.gif" alt="loader" title="loader"/>');	
		jQuery.post(
				PT_Ajax.ajaxurl,
				{
					// wp ajax action
			    	action: 'refreshJsonData',

					// send the nonce along with the request
					nextNonce: PT_Ajax.nextNonce
				},
				function (response) {
					jQuery('#drjsondataCont').html(response[0]);
				}
		);
}