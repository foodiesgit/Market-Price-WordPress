=== Display Real Time JSON data with Auto update ===
Contributors: Mahesh Bisen
Donate link: https://wp.masiwebsol.com/
Tags: Show JSON Data with HTML formatting, Third Party JSON data, JSON Data, Display Real time feed, Display real time event information.
Author URI: https://wp.masiwebsol.com/
Requires at least: 3.0
Tested up to: 4.9.5
Requires PHP: 5.4 and above
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display real time JSON data on Page/Post using simple ShortCode. It can be used for displaying real time event, data from third party site or application with auto refresh through Ajax in specified interval. 

== Description ==
= Overview =

Display real time JSON data on Page/Post using simple ShortCode. It can be used for displaying real time event, data from third party site or application.
Very user friendly, easy to use and can easily work with nested JSON data as well. You can set auto refresh time to display actual real time data. It can be used to display current song playing on any channel, for displaying real time pricing of any third party portal, real time event price etc. 

= Display Real Time JSON data with Auto update Features =

*	Display real time JSON data in preformatted HTML using format string.
*   Able to render nested JSON data in simple way.
*	Refresh data through AJAX in specified interval.

== Installation ==

= Automatic Installation =
> 1. Sign in to your WordPress site as an administrator.
> 2. In the main menu go to Plugins -> Add New.
> 3. Search for Display Real Time JSON data with Auto update and click install.
> 4. That's it. You are now ready to start displaying real time JSON data on your site using simple shortcode.

== Frequently Asked Questions ==

= How do I use it? = 

1.	Add JSON URL.
2.	Add formatted HTML along with format strings for real time data replacement. [<div>Entity 1: %%Entity1%%</div><div>Entity 2: %%Entity2%%</div><div>Entity 3: %%Entity3%%</div>]
3.	Set interval for refreshing the  data if required. 
4.	Use shortcode [show-json-Real Time-data] to display the data.

= How do I get help? =

Help is provided via the [plugin support forum](https://wordpress.org/support/plugin/wp-json-realtime-data-ajax) only.


== Screenshots ==
1. Admin Settings
2. Uses Screenshot



== Changelog ==

= 1.0 =
Initial release