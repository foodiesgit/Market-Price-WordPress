<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



// admin enqueue
function drjsondata_admin_enqueue() {

    // admin css
    wp_register_style( 'drjsondata-admin-css',plugins_url('../assets/css/drjsondata-admin.css',__FILE__),false,false );
    wp_enqueue_style( 'drjsondata-admin-css' );

    // admin js
    wp_enqueue_script( 'drjsondata-admin',plugins_url('../assets/js/admin.js',__FILE__),array( 'jquery' ),false );
    wp_localize_script( 'drjsondata-admin', 'drjsondata_object', array(
     'ajax_url' => admin_url( 'admin-ajax.php' ), 
     'we_value' => 1234 ) 
	);

}
add_action( 'admin_enqueue_scripts','drjsondata_admin_enqueue' );

// admin settings form
function drjsondata_admin_table() {


	if ( !current_user_can( "manage_options" ) )  {
		wp_die( __( "You do not have sufficient permissions to access this page." ) );
	}

	// save and update options
	if (isset($_POST['update'])) {

		$options['drjsondata-json-url'] = sanitize_text_field($_POST['drjsondata-json-url']);
		if ( empty( $options['drjsondata-json-url'] ) ) { 
			$options['drjsondata-json-url'] = ''; 
		}

		$options['drjsondata-data-format'] = htmlentities(stripslashes($_REQUEST['drjsondata-data-format']));
		if ( empty( $options['drjsondata-data-format'] ) ) { 
			$options['drjsondata-data-format'] = ''; 
		}

		$options['drjsondata-update-in-time'] = sanitize_text_field($_REQUEST['drjsondata-update-in-time']);
		if ( empty( $options['drjsondata-update-in-time'] ) ) { 
			$options['drjsondata-update-in-time'] = 0; 
		}


		update_option("drjsondata_options", $options);

		echo "<br /><div class='updated'><p><strong>"; _e("Settings Updated."); echo "</strong></p></div>";

	}

	// get options
	$options = get_option('drjsondata_options');

	if ( empty( $options['drjsondata-json-url'] ) ) { 
		$options['drjsondata-json-url'] = ''; 
	}

	if (empty($options['drjsondata-data-format'])) {
		$options['drjsondata-data-format'] = '<div>Entity 1: %%Entity1%%</div><div>Entity 2: %%Entity2%%</div><div>Entity 3: %%Entity3%%</div>'; 
	}

	if ( empty( $options['drjsondata-update-in-time'] ) ) { 
			$options['drjsondata-update-in-time'] = 0; 
	}

?>


<form method='post'>
	<div class='wrap'><h2>Display Realtime JSON Data through Ajax</h2></div>

	<table width='100%'><tr><td valign='top'>

	<div id="3" style="border: 1px solid #CCCCCC; display:block;">
		<div style="background-color:#E4E4E4;padding:8px;font-size:15px;color:#464646;font-weight: 700;border-bottom: 1px solid #CCCCCC;">
			&nbsp; Settings
		</div>
		<div style="background-color:#fff;padding:8px;">

			<table style="width: 100%;" cellpadding="5px" border="0">
				<tr>
					<td class='drjsondata_width'>
						<b>JSON URL: </b>
					</td>
					<td>
						<input type='text' name='drjsondata-json-url' value='<?php echo $options['drjsondata-json-url']; ?>' id="iddrjsondata-json-url" >
					</td>
					<td>Make sure JSON file is well formatted. <a href="javascript:drjsondata_fetchSampleJSONPreivewAdmin('<?php echo plugin_dir_url( __FILE__ ); ?>');" >Preview</a> <br /></td>
				</tr>
				<tr>
					<td class='drjsondata_width' valign="top"><b>Display Data: </b></td>
					<td><textarea type='text' name='drjsondata-data-format' id="iddrjsondata-data-format"><?php echo $options['drjsondata-data-format']; ?></textarea></td>
					<td valign="top">Add format string[enclosed between string %%] for all JSON entities. <a href="javascript:drjsondata_fetchSampleDataAdmin('<?php echo plugin_dir_url( __FILE__ ); ?>');" >Click Here</a> for displaying all JSON entities and formatted preview.
						<div id="idjsonPreviewCont" style="width: 100%; margin-top:15px;">
							<div class="previewHead" >&nbsp;&nbsp;JSON Preview</div>
							<div class="jsonPreviewCont" style="padding:10px !important;">Preview Container</div>
						</div>
						<div id="iddataPreviewCont" style="width: 100%; margin-top:15px;">
							<div class="previewHead" >&nbsp;&nbsp;Preview</div>
							<div class="dataPreviewCont" style="padding:10px !important;">Preview Container</div>
						</div>
						<div id="iddataPreviewCont" style="width: 100%; margin-top:15px;">
							<div class="previewHead" >&nbsp;&nbsp;Instructions</div>
							<div class="instructionsCont" style="padding:10px !important;">Add following shortcode for displaying in the site.<br/><pre>[show-json-realtime-data]</pre></div>
						</div>
						
					</td>
				</tr>
				<tr>
					<td class='drjsondata_width' valign="top">
						<b>Update Data in: </b>
					</td>
					<td valign="top">
						<input type='text' name='drjsondata-update-in-time' value='<?php echo $options['drjsondata-update-in-time']; ?>' id="iddrjsondata-update-in-time" ><span style="font-size:10px; font-style: italic; color: #9f9f9f;">1 sec = 1000, 2 secs = 2000, 3 secs = 3000 and so on</span>

					</td>
					<td valign="top">Enter time for updating data automatically without refreshing your window. <br/><i>Add 0  for keeping refresh inactive.</i></td>
				</tr>
			</table>

		</div>
	</div>


	<input type='hidden' name='update' value='1'>

	<table width='100%'>
		<tr>
			<td><br />
		<input type='submit' name='btn2' class='button-primary' style='font-size: 17px;line-height: 28px;height: 32px;float: left;' value='Save Settings'>
	</td></tr></table>

</form>

	</td><td width="3%" valign="top">

	</td><td width="24%" valign="top">


	
	</td><td width="2%" valign="top">



	</td></tr></table>

	<?php

}


add_action( 'wp_ajax_drjsondata_displayJsonDataPreview', 'drjsondata_displayJsonDataPreview' );
function drjsondata_displayJsonDataPreview() {

	// get options
    $options = get_option('drjsondata_options');

    if ( empty( $options['drjsondata-json-url'] ) ) { 
        $options['drjsondata-json-url'] = plugin_dir_url( __FILE__ ).'../sample.json'; 
    }

    if (empty($options['drjsondata-data-format'])) {
        $options['drjsondata-data-format'] = '<div>Entity 1: %%Entity1%%</div><div>Entity 2: %%Entity2%%</div><div>Entity 3: %%Entity3%%</div>'; 
    }

    // read data from remote JSON using wp http api
    $drjsondata_response    = wp_remote_get( $options['drjsondata-json-url'] );
    $drjsondata_http_code   = wp_remote_retrieve_response_code( $drjsondata_response );

    if( $drjsondata_http_code == 200 ) {
        $drjsondata_json_content = wp_remote_retrieve_body( $drjsondata_response );

	    // check if string is surrounded in double or single quotes
	    if ( preg_match('#^(\'|").+\1$#', $drjsondata_json_content) == 1) {
	        $rawData =  substr(stripslashes($drjsondata_json_content), 1, -1);
	    } else {
	        $rawData =  stripslashes($drjsondata_json_content);
	    }

	    // convert json content into array/object
	    $data_initially_called = json_decode($rawData, false);
	    
	    if( is_object($data_initially_called) ){
	        $data_initially_called = drjsondata_dismount( $data_initially_called );
	    }

	    $drjsondatdata = drjsondata_array_flatten($data_initially_called);

	    $arr1 = array();
	    $arr2 = array();

	    $usableFormatStrings = "";

	    foreach( $drjsondatdata as $key=>$val ) {
	        $arr1[] = '%%'.$key.'%%';
	        $arr2[] = $val;
	        $usableFormatStrings .= $key.","; 
	    }
	    
	    $prodata = stripcslashes($options['drjsondata-data-format']);
	    $processData = str_replace( $arr1, $arr2, $prodata );

    } else {
        $processData = '<span class="file_error">file error....code - '.$drjsondata_http_code.'</span>';
    }


    $response_build = array( html_entity_decode($processData), $usableFormatStrings);
    $response = json_encode( $response_build );

    // response output
    header( "Content-Type: application/json" );
    echo $response;

    wp_die();
}

add_action( 'wp_ajax_drjsondata_displayJsonPreview', 'drjsondata_displayJsonPreview' );
function drjsondata_displayJsonPreview() {

	// get options
    $options = get_option('drjsondata_options');

    if ( empty( $options['drjsondata-json-url'] ) ) { 
        $options['drjsondata-json-url'] = plugin_dir_url( __FILE__ ).'../sample.json'; 
    }

    // read data from remote JSON using wp http api
    $drjsondata_response    = wp_remote_get( $options['drjsondata-json-url'] );
    $drjsondata_http_code   = wp_remote_retrieve_response_code( $drjsondata_response );

    if( $drjsondata_http_code == 200 ) {
        $drjsondata_json_content = wp_remote_retrieve_body( $drjsondata_response );
    } else {
    	$drjsondata_json_content = 'error....code - '.$drjsondata_http_code;
    }

    
    $response_build 	= array( $drjsondata_json_content );
    $response 			= json_encode( $response_build );
    
    // response output
    header( "Content-Type: application/json" );
    echo $response;

    wp_die();
}