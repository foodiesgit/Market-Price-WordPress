<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


// add plugin naviagation
add_action( 'admin_menu', 'drjsondata_admin_menu', 20 );
function drjsondata_admin_menu() {
	add_menu_page( 'JSON Data', 'JSON Data', 'manage_options', 'drjsondata_admin_table', 'drjsondata_admin_table', 'dashicons-welcome-widgets-menus', 90 );
}


// plugin page links
add_filter('plugin_action_links', 'drjsondata_plugin_settings_link', 10, 2 );
function drjsondata_plugin_settings_link($links,$file) {
	
	if ($file == 'json-realtime-data-ajax/json-realtime-data-ajax.php') {		
		$settings_link = 	'<a href="admin.php?page=drjsondata_admin_table">' . __('Settings', 'PTP_LOC') . '</a>';
	}
	
	return $links; 
}