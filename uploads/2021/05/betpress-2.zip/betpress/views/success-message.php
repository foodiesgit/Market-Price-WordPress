<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<div class="success-holder">
        
    <?php echo $success_message; ?>
    
</div>