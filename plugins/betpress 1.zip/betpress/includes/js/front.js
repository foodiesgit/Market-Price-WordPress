jQuery(document).ready(function (response) { 
    //make stake input height equals the submit button height
    jQuery('#stake-input').css('min-height', jQuery('#submit-slip-button').css('height'));

    //fix height bugs in featured page
    jQuery('.table-col-featured-options').each(function(response) {
        var this_height = jQuery(this).css('height');
        var children = jQuery(this).children('.featured-bet-option-wrapper');

        jQuery(this).siblings('.table-col-featured-bet-event').css('height', this_height);

        jQuery.each(children, function (index, element) {
            jQuery(element).css('height', this_height);
        });

    });

	//lang changing redirection
    jQuery('#lang-type-switcher-dropdown').on('change', function (response) {

        var selected_option = jQuery(this).find('option:selected').val();
        var current_url = window.location.href;
        var query_params = window.location.search;
        var get_symbol = (query_params === '') ? '?' : '&';

        //change the desired lang
        window.location.replace(current_url + get_symbol + 'lang_type_changing=' + selected_option);
    });
	
	//gmt changing redirection
    jQuery('#gmt-type-switcher-dropdown').on('change', function (response) {

        var selected_option = jQuery(this).find('option:selected').val();
        var current_url = window.location.href;
        var query_params = window.location.search;
        var get_symbol = (query_params === '') ? '?' : '&';

        //change the desired lang
        window.location.replace(current_url + get_symbol + 'gmt_type_changing=' + selected_option);
    });	
	
	// balance changing redirection
    jQuery('#balance-type-switcher-dropdown').on('change', function (response) {

        var selected_option = jQuery(this).find('option:selected').val();
        var current_url = window.location.href;
        var query_params = window.location.search;
        var get_symbol = (query_params === '') ? '?' : '&';

        //change the desired balance
        window.location.replace(current_url + get_symbol + 'balance_type_changing=' + selected_option);
    });	
	
    //odd changing redirection
    jQuery('#odd-type-switcher-dropdown').on('change', function (response) {

        var selected_option = jQuery(this).find('option:selected').val();
        var current_url = window.location.href;
        var query_params = window.location.search;
        var get_symbol = (query_params === '') ? '?' : '&';

        //change the desired odd
        window.location.replace(current_url + get_symbol + 'odd_type_changing=' + selected_option);
    });

    //toggle bettings
    jQuery('span[class=toggle-btn]').on('click', function (response) {

        var selected_id = this.id;
        var selected = selected_id.split('--');
        var type = selected[0];
        var id = selected[1];

        var container = jQuery('#' + type + '-container-' + id);

        this.innerHTML = container.css('display') === 'none' ? i18n_front.toggle_symbol_minus : i18n_front.toggle_symbol_plus;

        container.slideToggle();

    });
	
    //add bet option
    jQuery('body').on('click','div[id^=bet-option-btn]', function (response) {

        jQuery('.bets-holder').html(i18n_front.loading);

        jQuery('#pw').html('');

//         jQuery('html, body').animate({
//             scrollTop: jQuery("#betslip-wrapper").offset().top - 70
//         }, 1000);

        var selected_option_id = this.id;
        var id = selected_option_id.split('-')[3];
        var name = this.innerHTML;

        jQuery.post(ajaxurl, {

            action: 'add_bet_option',
            bet_option_id: id,
            bet_option_name: name

        }, function (response) { //alert('hie');
			//alert(jQuery('#'+selected_option_id).attr('id');
			//jQuery(div[id^='#'+selected_option_id]).css('background-color',' #189970 !important');
			jQuery(".cat-container").next().toggle();
			if(response.indexOf('error-holder') == -1) {
				jQuery('.'+selected_option_id).parent().children('.bet-option-wrapper').removeClass('active');
				jQuery('.'+selected_option_id).addClass('active');
			}
            jQuery('.bets-holder').html(response);
			if(odds.length == 0)
            	jQuery('#pw').html('0.00');
			else{
				jQuery('#pw').html('');;
			}
        });
    });

    //delete bet option
    jQuery('.bets-holder').on('click', '.delete-bet-option', function (event) {

        event.preventDefault();

        jQuery('.bets-holder').html(i18n_front.loading);

        var id = this.id.split('-')[1];

        jQuery.post(ajaxurl, {

            action: 'delete_bet_option',
            bet_option_id: id

        }, function (response) {
            var selected_option_id = eval('"bet-option-btn-'+id+'"');
			jQuery('.'+selected_option_id).removeClass('active');
			jQuery('.bets-holder').html(response);
        });
    });

    //submit bet slip
    jQuery('button[id=submit-slip-button]').on('click', function (event) {
        event.preventDefault();

        jQuery(this).blur();

        jQuery('.bets-holder').html(i18n_front.loading);

        var bet_stake = jQuery('#stake-input').val();

        jQuery.post(ajaxurl, {

            action: 'submit_bet_slip',
            bet_stake: bet_stake

        }, function (response) {
            jQuery('.bets-holder').html(response);
            if(jQuery('.success-holder').length > 0){
            	jQuery(".bet-option-wrapper").removeClass("active");
            	jQuery(".bet-option-wrapper").css('background-color', '#505050');
            }
            jQuery('.points-holder').html(i18n_front.loading);

            jQuery.post(ajaxurl, {

                action: 'points_change'

            }, function (response) {

                jQuery('.points-holder').html(response);

            });
        });
    });

    //slips page, toggling a slip's bet options
    jQuery('.toggle-bet-options').on('click', function (response) {

        jQuery(this).next().toggle();

    });

});
