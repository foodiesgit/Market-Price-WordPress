<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<div class="updated">
    
    <p>
        
        <?php echo $update_message; ?>
        
    </p>
    
</div>