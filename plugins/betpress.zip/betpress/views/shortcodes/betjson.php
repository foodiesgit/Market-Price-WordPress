<?php
global $wpdb;

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>


<?php

//$curl = curl_init();

// curl_setopt_array($curl, [
//	CURLOPT_URL => "https://betsapi.com/docs/samples/bet365_inplay.json",
//	CURLOPT_RETURNTRANSFER => true,
//	CURLOPT_FOLLOWLOCATION => true,
//	CURLOPT_ENCODING => "",
//	CURLOPT_MAXREDIRS => 10,
//	CURLOPT_TIMEOUT => 30,
//	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//	CURLOPT_CUSTOMREQUEST => "GET",
//	CURLOPT_HTTPHEADER => [
//		"x-rapidapi-host: betsapi2.p.rapidapi.com",
//		"x-rapidapi-key: dd691c4e3cmsh8e8242a6dce1bebp1e7e24jsn7c992a6f0e33"
//	],
//]);

//$response = curl_exec($curl);
//$err = curl_error($curl);

//curl_close($curl);

//if ($err) {
//	echo "cURL Error #:" . $err;
//} else {
//	echo $response;
//}
?>
<?php
global $wpdb;
$user_ID = get_current_user_id();
$check = $wpdb->get_results('SELECT bet_options_ids FROM ' . $wpdb->prefix . 'bp_slips where status = "unsubmitted" AND user_id = ' . $user_ID);
$str_val = $check[0]->bet_options_ids;
$timezone = get_user_meta($user_ID, 'gmt_offset', true);
?>
<div class="bettings-wrapper">
    
<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST">                              
                
<?php foreach ($xml_data as $sport_name => $events): ?>
                
    <?php if (count($events) === 1): ?>
        
                <div class="sport-<?php echo $events['id']; ?>" style="display:block;">

                    <?php esc_attr_e('', 'betpress'); ?>

                </div>
                
    <?php endif; ?>
                
    <?php if (is_array($events)): ?>
                <?php 
				foreach($events as $kp => $sp){
				foreach($events[$kp] as $ku => $vl){
		        unset($events[$kp][$ku]['Resultado duplo']);
		        unset($events[$kp][$ku]['Resultado correcto ao intervalo']);
		        unset($events[$kp][$ku]['Resultado correcto']);
		        unset($events[$kp][$ku]['Resultado sem empate']);
		        unset($events[$kp][$ku]['Total de golos - acima/abaixo']);
		        unset($events[$kp][$ku]['Resultado ao intervalo/final']);
		        unset($events[$kp][$ku]['Oportunidade dupla - 1.ª parte']);
		        unset($events[$kp][$ku]['Oportunidade dupla - 2.ª parte']);
		        unset($events[$kp][$ku]['As duas equipas marcam']);
		        unset($events[$kp][$ku]['Resultado da 2.ª parte']);
		        unset($events[$kp][$ku]['Resultado ao intervalo']);
		        unset($events[$kp][$ku]['1.ª equipa a marcar']);
		        unset($events[$kp][$ku]['Último marcador']);
		        unset($events[$kp][$ku]['Total de golos na 1.ª parte']);
		        unset($events[$kp][$ku]['Resultado handicap']);
		        unset($events[$kp][$ku]['Resultado sem empate ao intervalo']);
		        unset($events[$kp][$ku]['Ambas as equipas marcam na 1.ª parte']);
		        unset($events[$kp][$ku]['1.º marcador']);
		        unset($events[$kp][$ku]['Marcador']);
		        unset($events[$kp][$ku]['Total de golos na 2.ª parte']);
		        unset($events[$kp][$ku]['Total de golos - linhas']);
		        unset($events[$kp][$ku]['Total de golos']);
		        unset($events[$kp][$ku]['Tempo do 1.º golo']);
		        unset($events[$kp][$ku]['Kups']);
		        unset($events[$kp][$ku]['Kups']);
		        unset($events[$kp][$ku]['Kups']);
				}
			}
				//echo '<pre>';print_r($events);exit; 
				?>
<?php foreach ($events as $event_name => $bet_events): ?>
<?php if ('id' != $event_name): 
$event_name = str_replace("Camp. do Mundo", "Taça do Mundo 2022", $event_name);
$event_name = str_replace("Inglaterra - Premier Lg.", "Inglaterra - Premier League", $event_name);
$event_name = str_replace("Espanha - Segunda", "Espanha - Segunda Liga", $event_name);
$event_name = str_replace("Amigáveis - Selecções", "Partidas Internacionais", $event_name);
$event_name = str_replace("Camp. da Europa", "Euro 2020", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
$event_name = str_replace("Mundo", "Taça", $event_name);
?>
<div class="sport-<?php echo $events['id']; ?>" style="display:block; color: #14805e !important">

                    <span class="events" for="event-<?php echo $bet_events['id']; ?>"><?php echo $event_name; ?></span>

                </div>
                
            <?php endif; ?>
                
            <?php if (is_array($bet_events)): ?>
                
                <?php foreach ($bet_events as $bet_event_name => $categories): ?>
                
<?php if ('id' != $bet_event_name):
$bet_event_name = str_replace("Universidad Central de Venezuela FC", "UCV FC", $bet_event_name);				
$bet_event_name = str_replace("Olimpia Asuncion", "Club Olimpia", $bet_event_name);
$bet_event_name = str_replace("San Jose Oruro", "San Jose", $bet_event_name);
$bet_event_name = str_replace("Libertad Asuncion", "Club Libertad", $bet_event_name);
$bet_event_name = str_replace("Atletico", "Atlético", $bet_event_name);
$bet_event_name = str_replace("Atlético Paranaense", "Atlético-PR", $bet_event_name);							
$bet_event_name = str_replace("Gremio", "Grêmio", $bet_event_name);
$bet_event_name = str_replace("Internacional RS", "Internacional", $bet_event_name);
$bet_event_name = str_replace("CA Huracan", "Huracán", $bet_event_name);
$bet_event_name = str_replace("Manchester United", "Man Utd", $bet_event_name);
$bet_event_name = str_replace("Manchester City", "Man City", $bet_event_name);
$bet_event_name = str_replace("Cerro Porteno", "Cerro Porteño", $bet_event_name);
$bet_event_name = str_replace("Atlético-MG", "Atlético Mineiro", $bet_event_name);							
$bet_event_name = str_replace("Nacional Montevideo", "Nacional (Uru)", $bet_event_name);
$bet_event_name = str_replace("Universidad Catolica", "Univ. Católica", $bet_event_name);
$bet_event_name = str_replace("Universidad Concepcion", "Univ. Concepción", $bet_event_name);
$bet_event_name = str_replace("Paris SG", "PSG", $bet_event_name);
$bet_event_name = str_replace("Liga de Quito", "LDU Quito", $bet_event_name);
$bet_event_name = str_replace("Penarol de Montevideo", "Peñarol", $bet_event_name);
$bet_event_name = str_replace("Zamora FC", "Zamora", $bet_event_name);
$bet_event_name = str_replace("Bordéus", "Bordeaux", $bet_event_name);
$bet_event_name = str_replace("Bahia Salvador BA", "Bahia", $bet_event_name);
$bet_event_name = str_replace("UANL Tigres", "Tigres UANL", $bet_event_name);
$bet_event_name = str_replace("CF Monterrey", "Monterrey", $bet_event_name);
$bet_event_name = str_replace("Atlético Independiente", "Independiente FC", $bet_event_name);
$bet_event_name = str_replace("Ceará CE", "Ceará", $bet_event_name);
$bet_event_name = str_replace("Uniclinic", "FC Atlético Cearense", $bet_event_name);
$bet_event_name = str_replace("Piaui PI", "Piaui", $bet_event_name);
$bet_event_name = str_replace("Goianesia GO", "Goianesia", $bet_event_name);
$bet_event_name = str_replace("Ipora GO", "Ipora EC", $bet_event_name);
$bet_event_name = str_replace("Boyaca Patriotas", "Patriotas FC", $bet_event_name);
$bet_event_name = str_replace("Valledupar", "Valledupar FC", $bet_event_name);
$bet_event_name = str_replace("Deportes Pereira", "Dep. Pereira", $bet_event_name);
$bet_event_name = str_replace("Red Bull Brasil SP", "Red Bull Brasil", $bet_event_name);
$bet_event_name = str_replace("Ituano SP", "Ituano", $bet_event_name);
$bet_event_name = str_replace("CS Alagoano", "CSA", $bet_event_name);
$bet_event_name = str_replace("Vitoria BA", "Vitória", $bet_event_name);
$bet_event_name = str_replace(" F.", " - Feminino", $bet_event_name);
$bet_event_name = str_replace("Colegiales", "CA Colegiales", $bet_event_name);
$bet_event_name = str_replace("CA All Boys Santa Rosa", "All Boys", $bet_event_name);
$bet_event_name = str_replace("CF America", "Club América", $bet_event_name);
$bet_event_name = str_replace("Tiburones Rojos de Veracruz", "Veracruz", $bet_event_name);
$bet_event_name = str_replace("Atlas de Guadalajara", "Atlas", $bet_event_name);
$bet_event_name = str_replace("Club Tijuana", "Tijuana", $bet_event_name);
$bet_event_name = str_replace("Deportivo Toluca", "Toluca", $bet_event_name);
$bet_event_name = str_replace("Gallos Blancos Queretaro", "Querétaro", $bet_event_name);
$bet_event_name = str_replace("Alebrijes De Oaxaca", "Oaxaca", $bet_event_name);
$bet_event_name = str_replace("CSD Dorados Sinaloa", "Dorados", $bet_event_name);
$bet_event_name = str_replace("Leones Negros UDEG", "Leones Negros", $bet_event_name);
$bet_event_name = str_replace("Cimarrones de Sonora", "Cimarrones", $bet_event_name);
$bet_event_name = str_replace("Mineros De Zacatecas", "M. Zacatecas", $bet_event_name);
$bet_event_name = str_replace("Club Celaya", "Celaya", $bet_event_name);
$bet_event_name = str_replace("Rio Ave FC", "Rio Ave", $bet_event_name);
$bet_event_name = str_replace("Sporting Braga", "SC Braga", $bet_event_name);
$bet_event_name = str_replace("Club Sport Emelec", "Emelec", $bet_event_name);
$bet_event_name = str_replace("Real Oviedo", "Oviedo", $bet_event_name);
$bet_event_name = str_replace("Gimnastic Tarragona", "Gimnastic", $bet_event_name);
$bet_event_name = str_replace("Albacete Balompie", "Albacete", $bet_event_name);
$bet_event_name = str_replace("CF Rayo Majadahonda", "Rayo Majadahonda", $bet_event_name);
$bet_event_name = str_replace("Zaragoza", "Zaragoça", $bet_event_name);
$bet_event_name = str_replace("Zenit São Petersburgo", "Zenit St Petersburg", $bet_event_name);
$bet_event_name = str_replace("Sydney Wanderers", "WS Wanderers", $bet_event_name);
$bet_event_name = str_replace("Adelaide United FC", "Adelaide United", $bet_event_name);
$bet_event_name = str_replace("Sydney FC Youth", "Sydney FC", $bet_event_name);
$bet_event_name = str_replace("Energie Cottbus", "Cottbus", $bet_event_name);
$bet_event_name = str_replace("Kickers Wurzburg", "Wurzburg Kickers", $bet_event_name);
$bet_event_name = str_replace("SpVgg Unterhaching", "Unterhaching", $bet_event_name);
$bet_event_name = str_replace("Meppen", "SV Meppen", $bet_event_name);
$bet_event_name = str_replace("Aalen", "VfR Aalen", $bet_event_name);
$bet_event_name = str_replace("NEC Nijmegen", "NEC", $bet_event_name);
$bet_event_name = str_replace("Jong PSV Eindhoven", "PSV - Reservas", $bet_event_name);
$bet_event_name = str_replace("Jong Utrecht", "Utrecht - Reservas", $bet_event_name);
$bet_event_name = str_replace("Jong Ajax Amsterdam", "Ajax - Reservas", $bet_event_name);
$bet_event_name = str_replace("Jong AZ Alkmaar", "AZ - Reservas", $bet_event_name);
$bet_event_name = str_replace("Volendam", "FC Volendam", $bet_event_name);
$bet_event_name = str_replace("RKC Waalwijk", "RKC", $bet_event_name);
$bet_event_name = str_replace("Cambuur Leeuwarden", "Cambuur", $bet_event_name);
$bet_event_name = str_replace("VVV Venlo", "VVV", $bet_event_name);
$bet_event_name = str_replace("SBV Excelsior", "Excelsior", $bet_event_name);
$bet_event_name = str_replace("PSV Eindhoven", "PSV", $bet_event_name);
$bet_event_name = str_replace("NAC Breda", "NAC", $bet_event_name);
$bet_event_name = str_replace("Zwolle", "PEC Zwolle", $bet_event_name);
$bet_event_name = str_replace("Borussia M'gladbach", "Mönchengladbach", $bet_event_name);
$bet_event_name = str_replace("Standard Liege", "Standard Liège", $bet_event_name);
$bet_event_name = str_replace("Royal Charleroi SC", "Charleroi", $bet_event_name);
$bet_event_name = str_replace("Antuérpia", "Antwerp", $bet_event_name);
$bet_event_name = str_replace("Oostende", "KV Oostende", $bet_event_name);
$bet_event_name = str_replace("Sint-Truidense VV", "Sint-Truidense", $bet_event_name);
$bet_event_name = str_replace("Royal Pari Sion", "Royal Pari FC", $bet_event_name);
$bet_event_name = str_replace("Deportivo Malacateco", "Malacateco", $bet_event_name);
$bet_event_name = str_replace("MIN T'wolves", "MIN Timberwolves", $bet_event_name);
$bet_event_name = str_replace("PHI Sixers", "PHI 76ers", $bet_event_name);
$bet_event_name = str_replace("PHO Suns", "PHX Suns", $bet_event_name);
$bet_event_name = str_replace("Carolina Hurricanes", "CAR Hurricanes", $bet_event_name);
$bet_event_name = str_replace("Boston Bruins", "BOS Bruins", $bet_event_name);
$bet_event_name = str_replace("New Jersey Devils", "NJ Devils", $bet_event_name);
$bet_event_name = str_replace("Pittsburgh Penguins", "PIT Penguins", $bet_event_name);
$bet_event_name = str_replace("Florida Panthers", "FLA Panthers", $bet_event_name);
$bet_event_name = str_replace("New York Islanders", "NY Islanders", $bet_event_name);
$bet_event_name = str_replace("Otawa Senators", "OTT Senators", $bet_event_name);
$bet_event_name = str_replace("Columbus Blue Jackets", "CLB Blue Jackets", $bet_event_name);
$bet_event_name = str_replace("Winnipeg Jets", "WIN Jets", $bet_event_name);
$bet_event_name = str_replace("Arizona Coyotes", "ARZ Coyotes", $bet_event_name);
$bet_event_name = str_replace("Anaheim Ducks", "ANA Ducks", $bet_event_name);
$bet_event_name = str_replace("Los Angeles Kings", "LA Kings", $bet_event_name);
$bet_event_name = str_replace("Los Angeles Galaxy", "LA Galaxy", $bet_event_name);
$bet_event_name = str_replace("Nashville Predators", "NAS Predators", $bet_event_name);
$bet_event_name = str_replace("Minnesota Wild", "MIN Wild", $bet_event_name);
$bet_event_name = str_replace("Tampa Bay Lightning", "TB Lightning", $bet_event_name);
$bet_event_name = str_replace("Detroit Red Wings", "DET Red Wings", $bet_event_name);
$bet_event_name = str_replace("Montreal Canadiens", "MON Canadiens", $bet_event_name);
$bet_event_name = str_replace("Vancouver Canucks", "VAN Canucks", $bet_event_name);
$bet_event_name = str_replace("Washington Capitals", "WAS Capitals", $bet_event_name);
$bet_event_name = str_replace("Philadelphia Flyers", "PHI Flyers", $bet_event_name);
$bet_event_name = str_replace("New York Rangers", "NY Rangers", $bet_event_name);
$bet_event_name = str_replace("Dallas Stars", "DAL Stars", $bet_event_name);
$bet_event_name = str_replace("Vegas Golden Knights", "VGS Golden Knights", $bet_event_name);
$bet_event_name = str_replace("Colorado Avalanche", "COL Avalanche", $bet_event_name);
$bet_event_name = str_replace("Toronto Maple Leafs", "TOR Maple Leafs", $bet_event_name);
$bet_event_name = str_replace("Calgary Flames", "CAL Flames", $bet_event_name);
$bet_event_name = str_replace("St Louis Blues", "STL Blues", $bet_event_name);
$bet_event_name = str_replace("St. Patrick's Athletic", "St Patricks", $bet_event_name);
$bet_event_name = str_replace("Waterford United", "Waterford", $bet_event_name);
$bet_event_name = str_replace("University College Dublin", "UC Dublin", $bet_event_name);
$bet_event_name = str_replace("Bohemians Dublin", "Bohemians", $bet_event_name);
$bet_event_name = str_replace("Krylia Sovetov Samara", "Krylia Sovetov", $bet_event_name);
$bet_event_name = str_replace("Ienissei Krasnoyarsk", "FK Yenisey", $bet_event_name);
$bet_event_name = str_replace("Ural Ecaterimburgo", "Ural", $bet_event_name);
$bet_event_name = str_replace("FC Krasnodar", "Krasnodar", $bet_event_name);
$bet_event_name = str_replace("Heart of Midlothian", "Heart", $bet_event_name);
$bet_event_name = str_replace("Greenock Morton", "Morton", $bet_event_name);
$bet_event_name = str_replace("Dundee United", "Dundee Utd", $bet_event_name);
$bet_event_name = str_replace("Queen of the South", "Queen of South", $bet_event_name);
$bet_event_name = str_replace("Inverness Caledonian Thistle", "Inverness CT", $bet_event_name);
$bet_event_name = str_replace("Náutico PE", "Náutico Capibaribe", $bet_event_name);
$bet_event_name = str_replace("Fortaleza CE", "Fortaleza EC", $bet_event_name);
$bet_event_name = str_replace("Confianca", "AD Confianca", $bet_event_name);
$bet_event_name = str_replace("Mixto MT", "Mixto", $bet_event_name);
$bet_event_name = str_replace("Chapecoense SC", "Chapecoense", $bet_event_name);
$bet_event_name = str_replace("Ypiranga RS", "Ypiranga", $bet_event_name);
$bet_event_name = str_replace("Brasil De Pelotas RS", "Brasil de Pelotas", $bet_event_name);
$bet_event_name = str_replace("América RN", "América de Natal", $bet_event_name);
$bet_event_name = str_replace("Salgueiro PE", "Salgueiro AC", $bet_event_name);
$bet_event_name = str_replace("Luch-Energia Vladivostok", "Luch-Energia", $bet_event_name);
$bet_event_name = str_replace("Krasnodar-2", "Krasnodar 2", $bet_event_name);
$bet_event_name = str_replace("SKA-Khabarovsk", "SKA Khabarovsk", $bet_event_name);
$bet_event_name = str_replace("Sibir Novosibirsk", "Sibir", $bet_event_name);
$bet_event_name = str_replace("Shinnik Iaroslavl", "Yaroslavl", $bet_event_name);
$bet_event_name = str_replace("Baltika Kaliningrado", "Baltika", $bet_event_name);
$bet_event_name = str_replace("FC Tiumen", "Tyumen", $bet_event_name);
$bet_event_name = str_replace("Mordovia Saransk", "M. Saransk", $bet_event_name);
$bet_event_name = str_replace("Avangard Kursk", "Kursk", $bet_event_name);
$bet_event_name = str_replace("Fakel Voronej", "F. Voronezh", $bet_event_name);
$bet_event_name = str_replace("Rotor Volgogrado", "R. Volgogrado", $bet_event_name);
$bet_event_name = str_replace("Torpedo Armavir", "Armavir", $bet_event_name);
$bet_event_name = str_replace("Karmiotissa Polemidion", "APK Karmiotissa", $bet_event_name);
$bet_event_name = str_replace("Real Espana", "Real España", $bet_event_name);
$bet_event_name = str_replace("Kapaz", "FK Kapaz", $bet_event_name);
$bet_event_name = str_replace("Sabah-2", "Sabah FK II", $bet_event_name);
$bet_event_name = str_replace("Fk Sumgayit Reserve", " Fk Sumgayit II", $bet_event_name);
$bet_event_name = str_replace("Pfk Neftci Baku-2", "Neftci Baku II", $bet_event_name);
$bet_event_name = str_replace("Garabagh-2", "FK Qarabag II", $bet_event_name);
$bet_event_name = str_replace("FK Sabayil-2", "Sabayil FC II", $bet_event_name);
$bet_event_name = str_replace("Deportivo La Equidad", "La Equidad", $bet_event_name);
$bet_event_name = str_replace("College Europa", "Europa FC", $bet_event_name);
$bet_event_name = str_replace("Club Almagro", "Almagro", $bet_event_name);
$bet_event_name = str_replace("Real Pilar FC", "Real Pilar", $bet_event_name);
$bet_event_name = str_replace("CD Honduras Progreso", "Honduras Progreso", $bet_event_name);
$bet_event_name = str_replace("Orlando City SC", "Orlando City", $bet_event_name);
$bet_event_name = str_replace("Cuiaba Esporte Clube", "Cuiabá EC", $bet_event_name);
$bet_event_name = str_replace("Operario MT", "Operário Várzea", $bet_event_name);							
$bet_event_name = str_replace("Operario FC MG", "Operário MT", $bet_event_name);							
$bet_event_name = str_replace("Lincoln Red Imps FC", "Lincoln Red Imps", $bet_event_name);							
$bet_event_name = str_replace("Mohun Bagan AC", "Mohun Bagan", $bet_event_name);							
$bet_event_name = str_replace("Operario MT", "Operário Várzea", $bet_event_name);							
$bet_event_name = str_replace("Operario FC MG", "Operário MT", $bet_event_name);							
$bet_event_name = str_replace("EM Deportivo Binacional", "Deportivo Binacional", $bet_event_name);							
$bet_event_name = str_replace("Universidad Cesar Vallejo", "Cesar Vallejo", $bet_event_name);							
$bet_event_name = str_replace("Union Comercio", "Unión Comercio", $bet_event_name);							
$bet_event_name = str_replace("Sport Boys Association", "Sport Boys", $bet_event_name);							
$bet_event_name = str_replace("UTC de Cajamarca", "U. de Cajamarca", $bet_event_name);							
$bet_event_name = str_replace("SC Paderborn 07", "Paderborn 07", $bet_event_name);							
$bet_event_name = str_replace("Hamburger SV", "Hamburgo", $bet_event_name);							
$bet_event_name = str_replace("FC St. Pauli - Hamburgo", "St. Pauli", $bet_event_name);							
$bet_event_name = str_replace("Dinamo Dresden", "Dynamo Dresden", $bet_event_name);							
$bet_event_name = str_replace("MVV Maastricht", "Maastricht", $bet_event_name);							
$bet_event_name = str_replace("Dinamo Dresden", "Dynamo Dresden", $bet_event_name);
$bet_event_name = str_replace("Newell's Old Boys", "Newells Old Boys", $bet_event_name);							
$bet_event_name = str_replace("Gimnasia Y Esgrima", "Gimnasia La Plata", $bet_event_name);							
$bet_event_name = str_replace("Estudiantes de La Plata", "Estudiantes LP", $bet_event_name);							
$bet_event_name = str_replace("San Martin San Juan", "San Martín de San Juan", $bet_event_name);
$bet_event_name = str_replace("Colon de Santa Fe", "Colón", $bet_event_name);							
$bet_event_name = str_replace("BRO Nets", "BKN Nets", $bet_event_name);							
$bet_event_name = str_replace("- FemininoC.", "F.C", $bet_event_name);							
$bet_event_name = str_replace("Erzgebirge Aue", "Aue", $bet_event_name);							
$bet_event_name = str_replace("Ferroviaria SP", "Ferroviária", $bet_event_name);							
$bet_event_name = str_replace("Botafogo SP", "Botafogo Ribeirão Preto", $bet_event_name);							
$bet_event_name = str_replace("São Bento SP", "São Bento", $bet_event_name);							
$bet_event_name = str_replace("Atlético Bucaramanga", "Bucaramanga", $bet_event_name);							
$bet_event_name = str_replace("Atlético Tubarao SC", "Atlético Tubarão", $bet_event_name);							
$bet_event_name = str_replace("Cucuta Deportivo", "Cúcuta", $bet_event_name);							
$bet_event_name = str_replace("Independiente Medellin", "Ind. Medellin", $bet_event_name);							
$bet_event_name = str_replace("Hercilio Luz FC", "Hercílio Luz", $bet_event_name);							
$bet_event_name = str_replace("Independiente Santa Fe", "Ind. Santa Fé", $bet_event_name);							
$bet_event_name = str_replace("Maidstone United", "Maidstone Utd", $bet_event_name);							
$bet_event_name = str_replace("Havant & Waterlooville", "H. & Waterlooville", $bet_event_name);							
$bet_event_name = str_replace("Tallinna FC Flora", "Flora Tallinn", $bet_event_name);							
$bet_event_name = str_replace("Parnu JK Vaprus", "JK Vaprus", $bet_event_name);							
$bet_event_name = str_replace("Rakvere JK Tarvas", "Rakvere JK", $bet_event_name);							
$bet_event_name = str_replace("Tallinna JK Legion", "TJK Legion", $bet_event_name);							
$bet_event_name = str_replace("Kohtla-Järve JK Järve", "JK Järve", $bet_event_name);							
$bet_event_name = str_replace("River Plate Asuncion", "Club River Plate", $bet_event_name);							
$bet_event_name = str_replace("FK Mladost Lucani", "FK Mladost", $bet_event_name);							
$bet_event_name = str_replace("FK Radnik Surdulica", "FK Radnik", $bet_event_name);							
$bet_event_name = str_replace("Proleter Novi Sad", "Novi Sad", $bet_event_name);							
$bet_event_name = str_replace("FK Backa BP", "FK Backa", $bet_event_name);							
$bet_event_name = str_replace("O'Higgins", "O Higgins", $bet_event_name);							
$bet_event_name = str_replace("Union La Calera", "La Calera", $bet_event_name);							
$bet_event_name = str_replace("Everton Vina", "Everton Viña", $bet_event_name);							
$bet_event_name = str_replace("Deportes Valdivia", "Valdivia", $bet_event_name);							
$bet_event_name = str_replace("Universidad de Chile", "Univ. de Chile", $bet_event_name);							
$bet_event_name = str_replace("Universitario De Popayan", "Popayan", $bet_event_name);							
$bet_event_name = str_replace("União San Felipe", "U. San Felipe", $bet_event_name);							
$bet_event_name = str_replace("Santiago Wanderers", "S. Wanderers", $bet_event_name);							
$bet_event_name = str_replace("Deportes Magallanes", "CD Magallanes", $bet_event_name);										
$bet_event_name = str_replace("Deportivo Saprissa", "Saprissa", $bet_event_name);							
$bet_event_name = str_replace("Sporting San Miguelito", "Miguelito", $bet_event_name);							
$bet_event_name = str_replace("Deportivo Walter Ferreti", "Walter Ferreti", $bet_event_name);							
$bet_event_name = str_replace("Juventus Managua", "Managua", $bet_event_name);							
$bet_event_name = str_replace("Instituto AC Cordoba", "Instituto AC", $bet_event_name);							
$bet_event_name = str_replace("Montevideo Wanderers", "M. Wanderers", $bet_event_name);							
$bet_event_name = str_replace("Talleres de Remedios de Escalada", "Talleres Remedios", $bet_event_name);					$bet_event_name = str_replace("Club Atlético Fenix", "CA Fênix", $bet_event_name);							
$bet_event_name = str_replace("SSD Monza 1912", "Monza 1912", $bet_event_name);							
$bet_event_name = str_replace("Deportivo Cuenca", "Dep. Cuenca", $bet_event_name);							
$bet_event_name = str_replace("Tecnico Universitario", "Universitario", $bet_event_name);							
$bet_event_name = str_replace("Jaguares De Cordoba", "Jaguares Córdoba", $bet_event_name);							
$bet_event_name = str_replace("Concordia Chiajna", "Concórdia", $bet_event_name);
$bet_event_name = str_replace("Imperatriz MA", "Imperatriz", $bet_event_name);							
$bet_event_name = str_replace("Sao Jose de Ribamar", "São José de Ribamar", $bet_event_name);							
$bet_event_name = str_replace("Sertaozinho", "Sertãozinho", $bet_event_name);							
$bet_event_name = str_replace("Santo Andre SP", "Santo Andre", $bet_event_name);							
$bet_event_name = str_replace("Atibaia SP", "Atibaia", $bet_event_name);							
$bet_event_name = str_replace("Maranhao MA", "Maranhão", $bet_event_name);							
$bet_event_name = str_replace("Queensland Lions", "Lions FC", $bet_event_name);							
$bet_event_name = str_replace("SKN St. Polten II", "St. Polten II", $bet_event_name);							
$bet_event_name = str_replace("SC Team Wiener Linien", "Team Wiener Linien", $bet_event_name);							
$bet_event_name = str_replace("Union Espanola", "Unión Española", $bet_event_name);							
$bet_event_name = str_replace("Independiente Del Valle", "Ind. Del Valle", $bet_event_name);							
$bet_event_name = str_replace("F. Bourg en Bresse Peronnas 01", "Bourg-Peronnas", $bet_event_name);							
$bet_event_name = str_replace("Boulogne Cote D'Opale", "Boulogne", $bet_event_name);							
$bet_event_name = str_replace("Le Mans UC 72", "Le Mans", $bet_event_name);							
$bet_event_name = str_replace("Rodez Aveyron", "Rodez", $bet_event_name);							
$bet_event_name = str_replace("Sannois-Saint-Gratien", "Entente SSG", $bet_event_name);							
$bet_event_name = str_replace("Jeanne d'Arc", "Jeanne Drancy", $bet_event_name);							
$bet_event_name = str_replace("FC Chambly Thelle", "Chambly Thelle FC", $bet_event_name);							
$bet_event_name = str_replace("Quevilly Rouen", "US Quevilly", $bet_event_name);							
$bet_event_name = str_replace("FC Villefranche", "Villefranche", $bet_event_name);							
$bet_event_name = str_replace("FC Rostov", "Rostov", $bet_event_name);							
$bet_event_name = str_replace("Union Magdalena", "Unión Magdalena", $bet_event_name);							
$bet_event_name = str_replace("CD Real San Andres", "Real San Andres", $bet_event_name);							
$bet_event_name = str_replace("KGHM Zaglebie Lubin", "Zaglebie Lubin", $bet_event_name);							
$bet_event_name = str_replace("KS Cracovia", "Cracovia Krakow", $bet_event_name);							
$bet_event_name = str_replace("Gimnasia y Esgrima Mendoza", "Gimnasia y Esgrima", $bet_event_name);							
$bet_event_name = str_replace("Coritiba PR", "Coritiba", $bet_event_name);
$bet_event_name = str_replace("Atlético-PR", "Athletico-PR", $bet_event_name);							
$bet_event_name = str_replace("Foz do Iguaçu PR", "Foz do Iguaçu", $bet_event_name);							
$bet_event_name = str_replace("Metropolitano Maringa PR", "Maringá FC", $bet_event_name);							
$bet_event_name = str_replace("Cascavel PR", "Cascavel CR", $bet_event_name);							
$bet_event_name = str_replace("Londrina PR", "Londrina", $bet_event_name);							
$bet_event_name = str_replace("Atlético Tubarão", "Tubarão", $bet_event_name);							
$bet_event_name = str_replace("Criciuma SC", "Criciúma", $bet_event_name);
$bet_event_name = str_replace("River PI", "River AC", $bet_event_name);							
$bet_event_name = str_replace("Altos PI", "AE Altos", $bet_event_name);							
$bet_event_name = str_replace("Hellas Verona", "Verona", $bet_event_name);							
$bet_event_name = str_replace("Padova", "Pádua", $bet_event_name);
$bet_event_name = str_replace("Atlético Lanus", "Lanús", $bet_event_name);
$bet_event_name = str_replace("Hebei China Fortune FC", "Hebei CFFC", $bet_event_name);
$bet_event_name = str_replace("- Feminino Bourg en Bresse Peronnas 01", "Bourg-Peronnas", $bet_event_name);
$bet_event_name = str_replace("Desportiva Perilima de Futebol", "Desportiva Perilima PB", $bet_event_name);
$bet_event_name = str_replace("CSP PB", "CSP", $bet_event_name);
$bet_event_name = str_replace("Universidad de Costa Rica", "UCR", $bet_event_name);
$bet_event_name = str_replace("Limon", "Limón FC", $bet_event_name);
$bet_event_name = str_replace("Santos de Guapiles", "Santos de Guápiles", $bet_event_name);
$bet_event_name = str_replace("Municipal Grecia", "AD Grecia", $bet_event_name);
$bet_event_name = str_replace("Guadalupe", "Guadalupe FC", $bet_event_name);
$bet_event_name = str_replace("Carmelita", "AD Carmelita", $bet_event_name);
$bet_event_name = str_replace("San Carlos", "AD San Carlos", $bet_event_name);
$bet_event_name = str_replace("Cartagines", "Cartaginés", $bet_event_name);
$bet_event_name = str_replace("Johor Darul Ta'zim II", "Johor Darul Takzim II", $bet_event_name);
$bet_event_name = str_replace("Pdrm", "PDRM", $bet_event_name);
$bet_event_name = str_replace("Chertanovo-2", "FK Chertanovo II", $bet_event_name);
$bet_event_name = str_replace("1 FK Pribram", "FK Pribram", $bet_event_name);				
$bet_event_name = str_replace("SFC Opava", "Opava", $bet_event_name);				
$bet_event_name = str_replace("Ask-Bsc Bruck/Leitha", "ASK/BSC Bruck Leitha", $bet_event_name);				
$bet_event_name = str_replace("Sturm Graz Am.", "SK Sturm Graz II", $bet_event_name);				
$bet_event_name = str_replace("Lendorf", "SV Lendorf", $bet_event_name);				
$bet_event_name = str_replace("Inter De Limeira SP", "Inter De Limeira", $bet_event_name);				
$bet_event_name = str_replace("Juventus SP", "CA Juventus", $bet_event_name);				
$bet_event_name = str_replace("Estudiantes Merida", "Estudiantes de Mérida", $bet_event_name);				
$bet_event_name = str_replace("Nacional Asuncion", "Nacional Asunción", $bet_event_name);
$bet_event_name = str_replace("South West Queensland Thunder", "SWQ Thunder", $bet_event_name);
$bet_event_name = str_replace("Eastern Suburbs Brisbane", "Eastern Suburbs", $bet_event_name);
$bet_event_name = str_replace("Kubanochka Krasnodar - Feminino", "K. Krasnodar - Feminino", $bet_event_name);
$bet_event_name = str_replace("Cayb Club Athletic Youssoufia Berrechid", "Youssoufia Berrechid", $bet_event_name);
$bet_event_name = str_replace("Wydad Casablanca", "WAC Casablanca", $bet_event_name);
$bet_event_name = str_replace("Mat Maghrib Association Tetouan", "MAT Tetouan", $bet_event_name);
$bet_event_name = str_replace("Hassania Agadir", "HUSA Agadir", $bet_event_name);
$bet_event_name = str_replace("Dhj Difaa Hassani Jdidi", "Difaa El Jadida", $bet_event_name);
$bet_event_name = str_replace("Cra de Hoceima", "Chabab Rif Hoceima", $bet_event_name);
$bet_event_name = str_replace("Khouribga", "OC Khourigba", $bet_event_name);
$bet_event_name = str_replace("Países Baixos", "Holanda", $bet_event_name);
$bet_event_name = str_replace(" M Sub-17", "M U17", $bet_event_name);
$bet_event_name = str_replace("Rigas Futbola Skola", "Rigas FS", $bet_event_name);
$bet_event_name = str_replace("FS Metta LU", "Metta/LU", $bet_event_name);
$bet_event_name = str_replace("Akhmat Grózni Juventude", "Akhmat Grozny (Res)", $bet_event_name);
$bet_event_name = str_replace("CSKA Moscovo J.", "CSKA Moscovo (Res)", $bet_event_name);
$bet_event_name = str_replace("Krylya Sovetov J.", "Krylia Sovetov (Res)", $bet_event_name);
$bet_event_name = str_replace("Rigas Futbola Skola", "Rigas FS", $bet_event_name);
$bet_event_name = str_replace("Spartak Moscovo Juventude", "Spartak de Moscovo (Res)", $bet_event_name);
$bet_event_name = str_replace("FC Orenburg J.", "FK Orenburg (Res)", $bet_event_name);
$bet_event_name = str_replace("Ufa Juventude", "FC Ufa - Reservas", $bet_event_name);
$bet_event_name = str_replace("FC Anif / Salzburg II", "USK FC Anif", $bet_event_name);
$bet_event_name = str_replace("Grodig", "SV Grodig", $bet_event_name);
$bet_event_name = str_replace("Traiskirchen Fcm", "FCM Traiskirchen", $bet_event_name);
$bet_event_name = str_replace("Jeonbuk Hyundai Motors", "Jeonbuk Motors", $bet_event_name);				
$bet_event_name = str_replace("Jeunesse Sportive Kairouanaise", "Jeunesse Sportive", $bet_event_name);				
$bet_event_name = str_replace("Juventude RS", "Juventude", $bet_event_name);				
$bet_event_name = str_replace("Polonia Warszawa", "Polônia Varsóvia", $bet_event_name);				
$bet_event_name = str_replace("Sokol Aleksandrow Lodzki", "Sokol Aleksandrow", $bet_event_name);				
$bet_event_name = str_replace("New York Red Bulls II", "NY Red Bulls II", $bet_event_name);				
$bet_event_name = str_replace("Esperance Sportive Tunis", "Esperance de Tunis", $bet_event_name);				
$bet_event_name = str_replace("KSZO Ostrowiec Swietokrzyski", "KSZO Ostrowiec", $bet_event_name);				
$bet_event_name = str_replace("MKS Podlasie Biala Podlaska", "Podlasie Biala Podlaska", $bet_event_name);				
$bet_event_name = str_replace("KS Hutnik Krakow SSA", "Hutnik Krakow", $bet_event_name);
$bet_event_name = str_replace("Club Deportivo Hispano Americano", "CD Hispano", $bet_event_name);	
$bet_event_name = str_replace("Floresta CE", "Floresta EC", $bet_event_name);
$bet_event_name = str_replace("Vitória PE", "Vitória das Tabocas", $bet_event_name);
$bet_event_name = str_replace("Jacuipense BA", "Jacuipense", $bet_event_name);
$bet_event_name = str_replace("Campinense", "Campinense Clube", $bet_event_name);
$bet_event_name = str_replace("Fluminense de Feira BA", "Fluminense de Feira", $bet_event_name);
$bet_event_name = str_replace("Sergipe SE", "CS Sergipe", $bet_event_name);
$bet_event_name = str_replace("Novorizontino SP", "Grêmio Novorizontino", $bet_event_name);
$bet_event_name = str_replace("Sao Caetano SP", "São Caetano", $bet_event_name);
$bet_event_name = str_replace("Caxias RS", "Caxias", $bet_event_name);
$bet_event_name = str_replace("Ferroviario", "Ferroviário", $bet_event_name);
$bet_event_name = str_replace("Etoile Sportive du Sahel", "Etoile Sportive Sahel", $bet_event_name);
$bet_event_name = str_replace("Bragantino Clube do Pará", "Bragantino PA", $bet_event_name);				
$bet_event_name = str_replace("Letónia", "Letônia", $bet_event_name);				
$bet_event_name = str_replace("Estónia", "Estônia", $bet_event_name);				
$bet_event_name = str_replace("Polónia", "Polônia", $bet_event_name);
$bet_event_name = str_replace("Incheon United", "Incheon Utd", $bet_event_name);				
$bet_event_name = str_replace("Suwon Samsung Bluewings", "Suwon Bluewings", $bet_event_name);				
$bet_event_name = str_replace("Seongnam Ilhwa", "Seongnam FC", $bet_event_name);				
$bet_event_name = str_replace("Gyeongnam", "Gyeongnam FC", $bet_event_name);				
$bet_event_name = str_replace("República Checa", "República Tcheca", $bet_event_name);				
$bet_event_name = str_replace("Sangju Sangmu Phoenix", "Sangju Sangmu", $bet_event_name);				
$bet_event_name = str_replace("APIA Leichhardt Tigers", "Apia L Tigers", $bet_event_name);				
$bet_event_name = str_replace("Hakoah", "Hakoah Sydney City East", $bet_event_name);				
$bet_event_name = str_replace("Kajaanin Haka", "Kajha", $bet_event_name);				
$bet_event_name = str_replace("Vaajakoski", "FC Vaajakoski", $bet_event_name);				
$bet_event_name = str_replace("Brann", "SK Brann", $bet_event_name);				
$bet_event_name = str_replace("Lillestrøm SK", "Lillestrøm", $bet_event_name);				
$bet_event_name = str_replace("Rosenborg BK", "Rosenborg", $bet_event_name);				
$bet_event_name = str_replace("Odds BK", "Odd BK", $bet_event_name);
$bet_event_name = str_replace("Tromsø IL", "Tromsø", $bet_event_name);				
$bet_event_name = str_replace("Strømsgodset IF", "Strømsgodset", $bet_event_name);
$bet_event_name = str_replace("Byaasen Toppfotball", "Byåsen", $bet_event_name);				
$bet_event_name = str_replace("Stjørdals-Blink", "Stjørdals/Blink", $bet_event_name);
$bet_event_name = str_replace("Kvik Halden", "Kvik Halden FK", $bet_event_name);
$bet_event_name = str_replace("Egersund IK", "Egersund", $bet_event_name);				
$bet_event_name = str_replace("Fram Larvik", "Fram", $bet_event_name);
$bet_event_name = str_replace("Sotra SK", "Sotra", $bet_event_name);				
$bet_event_name = str_replace("Oppsal", "Stjørdals/Blink", $bet_event_name);
$bet_event_name = str_replace("Port Melbourne Sharks", "Port Melbourne SC", $bet_event_name);
$bet_event_name = str_replace("Green Gully Cavaliers", "Green Gully", $bet_event_name);				
$bet_event_name = str_replace("Altona Magic SC", "Altona Magic", $bet_event_name);
$bet_event_name = str_replace("Heidelberg United", "Heidelberg Utd", $bet_event_name);				
$bet_event_name = str_replace("Kingston City FC", "Kingston City", $bet_event_name);
$bet_event_name = str_replace("Avondale Heights", "Avondale", $bet_event_name);
$bet_event_name = str_replace("B 93 Copenhagen", "B93 Copenhagen", $bet_event_name);
$bet_event_name = str_replace("Ringkobing", "Ringkøbing IF", $bet_event_name);
$bet_event_name = str_replace("Bronshoj", "Brønshøj", $bet_event_name);
$bet_event_name = str_replace("Hellerup IK", "HIK", $bet_event_name);
$bet_event_name = str_replace("Vejgaard BSK", "Vejgaard B", $bet_event_name);
$bet_event_name = str_replace("FC Sydvest 05", "FC Sydvest", $bet_event_name);
$bet_event_name = str_replace("AB Gladsaxe", "AB", $bet_event_name);
$bet_event_name = str_replace("- Feminino", "(Feminino)", $bet_event_name);
$bet_event_name = str_replace(" - ", " v ", $bet_event_name);
$bet_event_name = str_replace("FK Krasnodar Juventude", "Krasnodar (Res)", $bet_event_name);
$bet_event_name = str_replace("FC Sóchi J", "FC Sóchi (Res)", $bet_event_name);
$bet_event_name = str_replace("FC Tambov J", "FC Tambov (Res)", $bet_event_name);
$bet_event_name = str_replace("Armadale SC", "Armadale", $bet_event_name);
$bet_event_name = str_replace("Perth Glory FC Youth", "Perth Glory Sub-21", $bet_event_name);
$bet_event_name = str_replace("Adelaide United Youth", "Adelaide United Sub-21", $bet_event_name);
$bet_event_name = str_replace("West Adelaide FC", "West Adelaide", $bet_event_name);
$bet_event_name = str_replace("South Adelaide FC", "South Adelaide", $bet_event_name);
$bet_event_name = str_replace("Sunshine Coast Fire", "Sunshine Coast", $bet_event_name);
$bet_event_name = str_replace("Gold Coast Knights SC", "Gold Coast Knights", $bet_event_name);
$bet_event_name = str_replace("Eltersdorf", "SC Eltersdorf", $bet_event_name);
$bet_event_name = str_replace("FC Eintracht Bamberg 2010", "FC Eintracht Bamberg", $bet_event_name);
$bet_event_name = str_replace("JK Welco Elekter", "Tartu JK Welco", $bet_event_name);
$bet_event_name = str_replace("Flora Tallinn Sub-21", "Flora Tallinn II", $bet_event_name);
$bet_event_name = str_replace("Tallinna", "Tallinna JK Legion", $bet_event_name);
$bet_event_name = str_replace("JK Tallinna Kalev U21", "JK Tallinna Kalev II", $bet_event_name);
$bet_event_name = str_replace("Jalgpallikool Tammeka", "JK Tammeka Tartu", $bet_event_name);
$bet_event_name = str_replace("Utrecht v Reservas", "Utrecht - Reservas", $bet_event_name);
$bet_event_name = str_replace("PSV v Reservas", "PSV - Reservas", $bet_event_name);
$bet_event_name = str_replace("Ajax v Reservas", "Ajax - Reservas", $bet_event_name);
$bet_event_name = str_replace("AZ v Reservas", "AZ - Reservas", $bet_event_name);
$bet_event_name = str_replace("FC Basel", "Basileia", $bet_event_name);
$bet_event_name = str_replace("Luzern", "Lucerne", $bet_event_name);
$bet_event_name = str_replace("Sion", "FC Sion", $bet_event_name);							
$bet_event_name = str_replace("Zurique", "FC Zurique", $bet_event_name);										
$bet_event_name = str_replace("Wil v ", "Wil 1900 v ", $bet_event_name);										
$bet_event_name = str_replace(" v Wil", " v Wil 1900", $bet_event_name);										
$bet_event_name = str_replace("Grasshopper", "Grasshoppers", $bet_event_name);										
$bet_event_name = str_replace("PS Tira", "PS TIRA", $bet_event_name);										
$bet_event_name = str_replace("Persepar Kalteng Putra", "Kalteng Putra FC", $bet_event_name);	
$bet_event_name = str_replace("Arema Indonesia", "Arema FC", $bet_event_name);										
$bet_event_name = str_replace("Bhayangkara Surabaya United", "Bhayangkara FC", $bet_event_name);
$bet_event_name = str_replace("Oita Trinita", "Oita", $bet_event_name);										
$bet_event_name = str_replace("JEF United Chiba", "JEF Utd Chiba", $bet_event_name);										
$bet_event_name = str_replace("Tochigi", "Tochigi SC", $bet_event_name);										
$bet_event_name = str_replace("Ehime", "Ehime FC", $bet_event_name);										
$bet_event_name = str_replace("Gifu", "FC Gifu", $bet_event_name);										
$bet_event_name = str_replace("Kyoto", "Kyoto Sanga FC", $bet_event_name);										
$bet_event_name = str_replace("Tombense MG", "Tombense", $bet_event_name);										
$bet_event_name = str_replace("Paysandu PA", "Paysandu", $bet_event_name);										
$bet_event_name = str_replace("Sao Jose RS", "São José PA", $bet_event_name);										
$bet_event_name = str_replace("Remo", "Clube do Remo", $bet_event_name);										
$bet_event_name = str_replace("Globo RN", "Globo FC", $bet_event_name);										
$bet_event_name = str_replace("Santa Cruz", "Santa Cruz FC", $bet_event_name);										
$bet_event_name = str_replace("Manaus Fc/Am", "Manaus", $bet_event_name);										
$bet_event_name = str_replace("Latvia", "Letônia", $bet_event_name);										
$bet_event_name = str_replace("Republic of Korea ", "Coreia do Sul", $bet_event_name);										
$bet_event_name = str_replace("Hungary", "Hungria", $bet_event_name);										
$bet_event_name = str_replace("Thailand", "Tailândia", $bet_event_name);										
$bet_event_name = str_replace("Talk N Text Tropang Texters", "TNT KaTropa", $bet_event_name);							$bet_event_name = str_replace("Barangay Ginebra Kings", "Barangay Ginebra San Miguel", $bet_event_name);			$bet_event_name = str_replace("W.", "(Feminino)", $bet_event_name);										
$bet_event_name = str_replace("Sunshine Coast Rip", "USC Rip City", $bet_event_name);								$bet_event_name = str_replace("South West Metro Pirates", "SW Metro Pirates", $bet_event_name);
$bet_event_name = str_replace("Wil 1900lem II", "Willem II", $bet_event_name);				
$bet_event_name = str_replace(" (Virtual)", " SRL", $bet_event_name);
$bet_event_name = str_replace(" Fifa", " ", $bet_event_name);
$bet_event_name = str_replace("CFC Catalonia FC", "Catalonia FC (CFC)", $bet_event_name);
$bet_event_name = str_replace("Ez1 Ez1D 11", "Vamos Ez1d (EZ1)", $bet_event_name);
$bet_event_name = str_replace("Nfc Nyancat FC", "Nyancat (NFC)", $bet_event_name);
$bet_event_name = str_replace("Fin Fints", "Fints (FIN)", $bet_event_name);
$bet_event_name = str_replace("Cfi Confession", "Confession (CFI)", $bet_event_name);
$bet_event_name = str_replace("Nht Newton Heath", "Newton Heath (NHT)", $bet_event_name);
$bet_event_name = str_replace("Tbr Tabula Rasa", "Tabula Rasa (TBR)", $bet_event_name);
$bet_event_name = str_replace("Pnz Im Not Over", "Im Not Over (PNZ)", $bet_event_name);
$bet_event_name = str_replace("Aru Arukonda", "Arukonda (ARU)", $bet_event_name);
$bet_event_name = str_replace("Own Owned", "Owned (OWN)", $bet_event_name);
$bet_event_name = str_replace("Meg Megapolice", "Megapolice (MEG)", $bet_event_name);
$bet_event_name = str_replace("Xal Xalinho FC", "Xalinho FC (XAL)", $bet_event_name);

if ($event_name == 'Copa Libertadores') {
$bet_event_name = str_replace("Guarani", "Club Guarani", $bet_event_name);
}
				
if ($event_name == 'Copa Sulamericana') {
$bet_event_name = str_replace("Guarani", "Club Guarani", $bet_event_name);
}
				
if ($event_name == 'Paraguai - Division Profesional') {
$bet_event_name = str_replace("Guarani", "Club Guarani", $bet_event_name);
}				

if ($event_name == 'Brasil - Campeonato Carioca') {
$bet_event_name = str_replace("Boavista", "Boavista SC Saquarema", $bet_event_name);
}
				
if ($event_name == 'Portugal - Liga Zon Sagres') {							
$bet_event_name = str_replace("Nacional", "CD Nacional", $bet_event_name);
}

if ($event_name == 'Colômbia - Primera B') {							
$bet_event_name = str_replace("Atlético", "Atlético Cali", $bet_event_name);
}	
				
$bet_event_name = str_replace("Central PE", "Central SC", $bet_event_name);
$bet_event_name = str_replace("Macae Esporte RJ", "Macaé Esporte RJ", $bet_event_name);
$bet_event_name = str_replace("Unirb FC BA", "UNIRB FC", $bet_event_name);
$bet_event_name = str_replace("Frei Paulistano SE", "AD Frei Paulistano", $bet_event_name);							
$bet_event_name = str_replace("Cs Maruinense Se", "CS Maruinense", $bet_event_name);							
$bet_event_name = str_replace("Afogados Ingazeira PE", "Afogados da Ingazeira FC", $bet_event_name);
$bet_event_name = str_replace("GE Juventus SC", "Juventus SC", $bet_event_name);							
$bet_event_name = str_replace("Doce Mel EC BA", "Doce Mel Esporte Clube", $bet_event_name);							
$bet_event_name = str_replace("Alagoinhas Atlético Clube", "Alagoinhas AC", $bet_event_name);							
$bet_event_name = str_replace("SE Juventude MA", "Juventude MA", $bet_event_name);							
$bet_event_name = str_replace("Pouso Alegre MG", "Pouso Alegre", $bet_event_name);							
$bet_event_name = str_replace("Coimbra EC MG", "Coimbra EC", $bet_event_name);							
$bet_event_name = str_replace("Patrocinense MG", "CA Patrocinense", $bet_event_name);							
$bet_event_name = str_replace("Athletic Club Sjdr MG", "Athletic Club MG", $bet_event_name);							
$bet_event_name = str_replace("Aimore RS", "Aimoré", $bet_event_name);							
$bet_event_name = str_replace("CE Bento Goncalves RS", "Esportivo Bento Goncalves", $bet_event_name);
$bet_event_name = str_replace("Novo Hamburgo RS", "Novo Hamburgo", $bet_event_name);							
$bet_event_name = str_replace("Urt MG", "União Recreativa dos Trabalhadores", $bet_event_name);							
$bet_event_name = str_replace("Uberlandia", "Uberlândia", $bet_event_name);							
$bet_event_name = str_replace("Itabaiana SE", "Itabaiana", $bet_event_name);							
$bet_event_name = str_replace("Boca Junior SE", "Sociedade Boca Júnior", $bet_event_name);							
$bet_event_name = str_replace("Anapolis GO", "Anapolis FC", $bet_event_name);							
$bet_event_name = str_replace("Grêmio Anapolis GO", "Gremio Anapolis", $bet_event_name);							
$bet_event_name = str_replace("Jataiense GO", "AE Jataiense", $bet_event_name);							
$bet_event_name = str_replace("EC Prospera SC", "EC Prospera", $bet_event_name);							
$bet_event_name = str_replace("Jaragua EC", "Jaraguá EC", $bet_event_name);
$bet_event_name = str_replace("Crac GO", "CRAC", $bet_event_name);				
$bet_event_name = str_replace("Western WS Wanderers (Feminino)", "WS Wanderers (Feminino)", $bet_event_name);
$bet_event_name = str_replace("Dorense SE", "Dorense", $bet_event_name);
$bet_event_name = str_replace("Ad Atlético Gloriense Se", "AD Atlética Gloriense", $bet_event_name);
$bet_event_name = str_replace("Lagarto SE", "Lagarto FC", $bet_event_name);
$bet_event_name = str_replace("Serc MS", "SERC (Chapadão)", $bet_event_name);
$bet_event_name = str_replace("Novoperario", "Novoperario FC", $bet_event_name);
$bet_event_name = str_replace("Dourados Ac Ms", "Dourados AC", $bet_event_name);
$bet_event_name = str_replace("Se Tiradentes Pi", "Tiradentes PI", $bet_event_name);
$bet_event_name = str_replace("Fluminense Ec Pi", "Fluminense PI", $bet_event_name);				

if ($sport_name == 'Basquetebol') {
$bet_event_name = str_replace("Dijon", "JDA Dijon Basket", $bet_event_name);
$bet_event_name = str_replace("Estrasburgo", "SIG Strasbourg", $bet_event_name);
$bet_event_name = str_replace("Groningen", "Donar Groningen", $bet_event_name);
$bet_event_name = str_replace("Rotterdam Basketbal College", "Feyenoord Basketbal", $bet_event_name);
$bet_event_name = str_replace("Nurnberg", "Nürnberg Falcons BC", $bet_event_name);
$bet_event_name = str_replace("Heidelberg", "Academics Heidelberg", $bet_event_name);
$bet_event_name = str_replace("Leicester", "Leicester Riders", $bet_event_name);
$bet_event_name = str_replace("Plymouth", "Plymouth Raiders", $bet_event_name);
$bet_event_name = str_replace("Verona", "Tezenis Verona", $bet_event_name);
$bet_event_name = str_replace("Torino", "Basket Torino", $bet_event_name);
$bet_event_name = str_replace("Spm Shoeters Den Bosch", "Heroes Den Bosch", $bet_event_name);
$bet_event_name = str_replace("Newcastle", "Newcastle Eagles", $bet_event_name);
$bet_event_name = str_replace("Panathinaikos", "Panathinaikos BC", $bet_event_name);
$bet_event_name = str_replace("PAOK Thessaloniki", "PAOK BC", $bet_event_name);
$bet_event_name = str_replace("Sheffield", "Sheffield Sharks", $bet_event_name);
$bet_event_name = str_replace("Bayern Munique", "Bayern München Basket", $bet_event_name);
$bet_event_name = str_replace("Real Madrid", "Real Madrid Basket", $bet_event_name);
$bet_event_name = str_replace("CSKA Moscow", "CSKA Moscow Basket", $bet_event_name);
$bet_event_name = str_replace("Monaco", "AS Monaco Basket", $bet_event_name);
$bet_event_name = str_replace("Trapani", "Pallacanestro", $bet_event_name);
$bet_event_name = str_replace("Valência", "Valencia Basket", $bet_event_name);
$bet_event_name = str_replace("Murcia", "UCAM Murcia Basket", $bet_event_name);
$bet_event_name = str_replace("London", "London Lions", $bet_event_name);
$bet_event_name = str_replace("Chemnitz", "BV Chemnitz 99", $bet_event_name);
$bet_event_name = str_replace("Caceres Patrimonio", "Pallacanestro", $bet_event_name);
$bet_event_name = str_replace("Huesca", "Peñas Huesca", $bet_event_name);
$bet_event_name = str_replace("Granada", "CB Granada", $bet_event_name);
$bet_event_name = str_replace("Melilla", "Melilla Baloncesto", $bet_event_name);
$bet_event_name = str_replace("Cb Tizona", "Ford Burgos", $bet_event_name);
$bet_event_name = str_replace("Akasvayu Girona", "Basquet Girona", $bet_event_name);
$bet_event_name = str_replace("Nantes", "Nantes Atlantique", $bet_event_name);
$bet_event_name = str_replace("Denain", "AS Denain", $bet_event_name);
$bet_event_name = str_replace("Union Poitiers Basket 86", "Poitiers Basket 86", $bet_event_name);
$bet_event_name = str_replace("Lille", "Lille Métropole", $bet_event_name);
$bet_event_name = str_replace("MMT Estudiantes", "Movistar Estudiantes", $bet_event_name);
$bet_event_name = str_replace("Fuenlabrada", "Urbas Fuenlabrada", $bet_event_name);
}					
				?>
                <div class="event-<?php echo $bet_events['id']; ?>" style="display:block">              

                    <span class="match" for="bet-event-<?php echo $categories['id']; ?>"><?php echo $bet_event_name;?></span>

                </div>
                    <?php endif; ?>
                    <?php if (is_array($categories)): ?>
                
                        <?php foreach ($categories as $category_name => $bet_options): ?>
<?php if ('id' != $category_name):
				
//$category_name = str_replace("Resultado sem empate", "Empate Anula Aposta", $category_name);
//$category_name = str_replace("Resultado", "Resultado Final", $category_name);
//$category_name = str_replace("Resultado Final correcto", "Resultado Correto", $category_name);
//$category_name = str_replace("Resultado Final ao intervalo", "Intervalo - Resultado", $category_name);
//$category_name = str_replace("As duas equipas marcam", "Para Ambos os Times Marcarem", $category_name);
//$category_name = str_replace("Total de golos - acima/abaixo", "Gols Mais/Menos", $category_name);
//$category_name = str_replace("1.ª equipa a marcar", "Primeiro Time a Marcar", $category_name);
//$category_name = str_replace("Resultado Final handicap", "Handicap - Resultado", $category_name);
//$category_name = str_replace("Oportunidade dupla - 1.ª parte", "1° Tempo - Dupla Hipótese", $category_name);
//$category_name = str_replace("Oportunidade dupla - 2.ª parte", "2° Tempo - Dupla Hipótese", $category_name);
//$category_name = str_replace("Resultado Final da 2.ª parte", "Resultado do 2° Tempo", $category_name);
//$category_name = str_replace("Total de golos na 1.ª parte", "1º Tempo - Total de Gols", $category_name);
//$category_name = str_replace("Ambas as equipas marcam na 1.ª parte", "1º Tempo - Para Ambos os Times Marcarem", $category_name);
//$category_name = str_replace("Intervalo - Resultado/final", "Intervalo / Final do Jogo", $category_name);
//$category_name = str_replace("Vencedor do jogo", "Para Vencer a Partida", $category_name);
//$category_name = str_replace("Vencedor do encontro", "Para Ganhar a Partida", $category_name);
//$category_name = str_replace("Total de pontos", "Totais do Jogo", $category_name);
//$category_name = str_replace("Resultado Final final", "Resultado Final", $category_name);
//$category_name = str_replace("Vencedor do combate", "Para Ganhar a Luta", $category_name);
//$category_name = str_replace("Tempo do 1.º golo", "Momento do Primeiro Gol", $category_name);
//$category_name = str_replace("1.º marcador", "Primeiro Jogador a Marcar um Gol", $category_name);
//$category_name = str_replace("Último marcador", "Último Jogador a Marcar um Gol", $category_name);
//$category_name = str_replace("Marcador", "Para Marcar a Qualquer Momento", $category_name);
//$category_name = str_replace("Total de jogos", "Total de Jogos", $category_name);
//$category_name = str_replace("Total de sets", "Total de Sets", $category_name);
//$category_name = str_replace("Aposta de sets", "Apostas no Set", $category_name);
//$category_name = str_replace("Handicap - Resultado de runs", "Handicap Alternativo", $category_name);
//$category_name = str_replace("Total de runs", "Totais do Jogo", $category_name);
//              if ($sport_name == 'Basquetebol') {
//$category_name = str_replace("Resultado Final", "Odds - Incluíndo Empate", $category_name); 
			  // }				
              ?>
                <div class="bet-event-<?php echo $categories['id']; ?>" style="display:block; color: #dd0000; font-family: Verdana !important; font-size: 16px!important">

                    <span class="m_name" for="category-<?php echo $bet_options['id']; ?>"><?php echo $category_name; ?></span>

                </div>
		
<?php foreach ($bet_options as $bet_option_name => $bet_option_odd): ?>
<?php if ('id' != $bet_option_name): ?>	
<?php 
$div_home = substr($bet_event_name, 0, strpos($bet_event_name, " v "));
$div_away = end(explode(" v ", $bet_event_name));
?>
	
<div class="bet-option-wrapper bet-option-btn-<?php echo $bet_option_odd['id']; ?>" id="bet-option-btn-<?php echo $bet_option_odd['id']; ?>" style="width: 50%; margin-left:0px;padding: 6px!important;">

<?php if ($bet_option_name == "%1%"): ?>
<span style="color: #fff!important;" id="btn-<?php echo $bet_option_odd['id']; ?>"><?php echo $div_home; ?></span>   
<?php endif; ?>	
	
<?php if ($bet_option_name == "%2%"): ?>
<span style="color: #fff!important;" id="btn-<?php echo $bet_option_odd['id']; ?>"><?php echo $div_away; ?></span>               
<?php endif; ?>	
	
<?php if (($bet_option_name != "%1%") && ($bet_option_name != "%2%")): ?>
<span style="color: #fff!important;" id="btn-<?php echo $bet_option_odd['id']; ?>"><?php echo $bet_option_name; ?></span>               
<?php endif; ?>

<span style="color: #ffdf1b!important;float:right!important;font-size:13px!important;font-family:verdana!important;" id="btn-<?php echo $bet_option_odd['id']; ?>"> <?php echo apply_filters('cipbet_odd', $bet_option_odd['odd']); ?></span>

                </div>		                           
		
	                          <?php endif; ?>
                      <?php endforeach; ?>
		
		                        <?php endif; ?>
                        <?php endforeach; ?>

                    <?php endif; ?>
	
                <?php endforeach; ?>
                
            <?php endif; ?>
                
        <?php endforeach; ?>
                
    <?php endif; ?>
                
<?php endforeach; ?>
 </form>